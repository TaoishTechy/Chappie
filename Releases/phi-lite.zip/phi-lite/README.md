# Φ-Lite

Slim multimodal meta-cognitive agent for Raspberry Pi 5. One Python process. Everything else is JSON or JSONL.

## Layout

| File | Role |
| --- | --- |
| `phi_lite.py` | Sole runtime: sensors (mocked if absent), RG pool, GRU world model, self-model fixed point, MCFE policy, HTTP ASCII dashboard |
| `config.json` | Hardware, dims, cycle time, paths |
| `architecture.json` | Module graph, actions, dataflow |
| `safety.json` | Hard rules and action masks |
| `dashboard.json` | ASCII layout metadata |
| `weights.json` | Tiny deterministic matrices (created on first run) |
| `state.json` | Persisted latent / self / prompt |
| `ledger.jsonl` | Boundary-ledger ring history |
| `logs.jsonl` | Action audit trail |

## Run

```bash
cd phi-lite
python3 phi_lite.py
```

Open `http://127.0.0.1:8080/` (HTML + ASCII, no JavaScript) or `http://127.0.0.1:8080/ascii`.

## Pi notes

Replace mock encoders with OpenCV / sounddevice / piper when hardware is present. Point `config.json` video.device and audio settings accordingly. Optional Coral TPU is out of band; keep the same JSON weight schema or swap `weights.json` for a TFLite path later.
