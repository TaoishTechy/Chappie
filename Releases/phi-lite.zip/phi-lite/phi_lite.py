#!/usr/bin/env python3
"""Φ-Lite — single-file slim multimodal meta-cognitive agent.

Hardware I/O is mocked when devices are absent. Architecture, safety,
dashboard layout, weights, and ledger live in JSON / JSONL.
"""
from __future__ import annotations

import json
import math
import os
import random
import threading
import time
from html import escape as html_escape
from collections import deque
from datetime import datetime
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

try:
    import numpy as np
except ImportError:  # pragma: no cover
    np = None

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)


def load_json(name: str, default=None):
    path = ROOT / name
    if not path.exists():
        return default if default is not None else {}
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_json(name: str, data) -> None:
    path = ROOT / name
    tmp = path.with_suffix(".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")
    tmp.replace(path)


def append_jsonl(name: str, rec: dict) -> None:
    with (ROOT / name).open("a", encoding="utf-8") as f:
        f.write(json.dumps(rec, separators=(",", ":")) + "\n")


CFG = load_json("config.json")
ARCH = load_json("architecture.json")
SAFETY = load_json("safety.json")
DASH = load_json("dashboard.json")
ACTIONS = ARCH.get("actions", ["IDLE", "SPEAK"])


def rng_matrix(rows: int, cols: int, seed: int) -> list:
    rnd = random.Random(seed)
    scale = 1.0 / math.sqrt(max(cols, 1))
    return [[(rnd.random() * 2 - 1) * scale for _ in range(cols)] for _ in range(rows)]


def ensure_weights() -> dict:
    w = load_json(CFG["paths"]["weights"], None)
    if w and "fusion" in w:
        return w
    d = CFG["dims"]
    w = {
        "note": "Deterministic tiny weights stored as JSON arrays. Substitutable by TFLite later.",
        "fusion": {"W": rng_matrix(d["b"], d["z_v"] + d["z_a"], 1), "b": [0.0] * d["b"]},
        "world": {
            "Wz": rng_matrix(d["h"], d["coarse"], 2),
            "Uz": rng_matrix(d["h"], d["h"], 3),
            "Wr": rng_matrix(d["h"], d["coarse"], 4),
            "Ur": rng_matrix(d["h"], d["h"], 5),
            "Wh": rng_matrix(d["h"], d["coarse"], 6),
            "Uh": rng_matrix(d["h"], d["h"], 7),
        },
        "self": {
            "W": rng_matrix(d["s"], d["h"] + d["s"], 8),
            "b": [0.0] * d["s"],
        },
        "policy": {
            "W": rng_matrix(len(ACTIONS), d["h"] + d["s"] + 8, 9),
            "b": [0.0] * len(ACTIONS),
        },
        "attn": {"W": rng_matrix(1, d["h"], 10), "b": [0.0]},
        "horizon": {"W": rng_matrix(len(CFG["horizons"]), d["h"], 11), "b": [0.0] * len(CFG["horizons"])},
    }
    save_json(CFG["paths"]["weights"], w)
    return w


W = ensure_weights()


def matvec(Wmat, x):
    if np is not None:
        return (np.array(Wmat, dtype=float) @ np.array(x, dtype=float)).tolist()
    out = []
    for row in Wmat:
        out.append(sum(a * b for a, b in zip(row, x)))
    return out


def tanh_v(xs):
    return [math.tanh(v) for v in xs]


def sigmoid_v(xs):
    out = []
    for v in xs:
        v = max(-20.0, min(20.0, v))
        out.append(1.0 / (1.0 + math.exp(-v)))
    return out


def softmax(xs):
    m = max(xs)
    ex = [math.exp(v - m) for v in xs]
    s = sum(ex) or 1.0
    return [v / s for v in ex]


def add(a, b):
    return [x + y for x, y in zip(a, b)]


def mul(a, b):
    return [x * y for x, y in zip(a, b)]


def l2(a):
    return math.sqrt(sum(x * x for x in a))


def entropy(p):
    return -sum(q * math.log(q + 1e-12) for q in p)


class Ledger:
    def __init__(self, cap: int, dim: int):
        self.cap = cap
        self.dim = dim
        self.buf = deque(maxlen=cap)
        self._load()

    def _load(self):
        path = ROOT / CFG["paths"]["ledger"]
        if not path.exists():
            return
        for line in path.read_text(encoding="utf-8").splitlines()[-self.cap :]:
            try:
                rec = json.loads(line)
                self.buf.append(rec["b"])
            except Exception:
                continue

    def push(self, b):
        self.buf.append(list(b))
        append_jsonl(CFG["paths"]["ledger"], {"t": time.time(), "b": [round(x, 5) for x in b]})

    def matrix(self):
        if not self.buf:
            return [[0.0] * self.dim]
        return list(self.buf)


class Agent:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = True
        self.paused = False
        self.cycle = 0
        self.prompt = ""
        self.outputs = deque(maxlen=8)
        self.logs = deque(maxlen=6)
        self.h = [0.0] * CFG["dims"]["h"]
        self.s = [0.0] * CFG["dims"]["s"]
        self.pi = [1.0 / len(ACTIONS)] * len(ACTIONS)
        self.horizon = 5
        self.entropy = 0.0
        self.fp_err = 0.0
        self.fp_iter = 0
        self.last_action = "IDLE"
        self.last_act_t = 0.0
        self.lat_ms = 0.0
        self.video_fps = 0.0
        self.audio_hz = CFG["audio"]["sample_rate"]
        self.motion = 0.0
        self.prev_frame = None
        self.ledger = Ledger(CFG["ledger"]["capacity"], CFG["ledger"]["dim"])
        self.start = time.time()
        self._restore()

    def _restore(self):
        st = load_json(CFG["paths"]["state"], {})
        self.cycle = int(st.get("cycle", 0))
        self.prompt = st.get("prompt", "")
        if st.get("h"):
            self.h = st["h"]
        if st.get("s"):
            self.s = st["s"]

    def persist(self):
        save_json(
            CFG["paths"]["state"],
            {
                "cycle": self.cycle,
                "prompt": self.prompt,
                "h": [round(x, 5) for x in self.h],
                "s": [round(x, 5) for x in self.s],
                "last_action": self.last_action,
                "ts": time.time(),
            },
        )

    def mock_frame(self):
        w, h = CFG["video"]["width"], CFG["video"]["height"]
        t = time.time()
        # Synthetic moving blob encoded as flattened mean RGB stats only
        cx = 0.5 + 0.3 * math.sin(t * 0.7)
        cy = 0.5 + 0.3 * math.cos(t * 0.5)
        return {"w": w, "h": h, "cx": cx, "cy": cy, "t": t}

    def mock_audio(self):
        # Energy + two tones as a 8-d sketch of a 1s chunk
        t = time.time()
        return [0.1 + 0.05 * math.sin(t), math.sin(t * 2), math.cos(t * 1.3), 0.02]

    def encode_video(self, frame):
        # Deterministic 32-d embedding from mock kinematics (stand-in for CNN)
        d = CFG["dims"]["z_v"]
        base = [
            frame["cx"],
            frame["cy"],
            math.sin(frame["t"]),
            math.cos(frame["t"]),
        ]
        z = []
        for i in range(d):
            z.append(math.tanh(base[i % 4] * (1 + 0.07 * i) + 0.01 * i))
        if self.prev_frame:
            self.motion = abs(frame["cx"] - self.prev_frame["cx"]) + abs(
                frame["cy"] - self.prev_frame["cy"]
            )
        self.prev_frame = frame
        self.video_fps = CFG["video"]["fps"]
        return z

    def encode_audio(self, feat):
        d = CFG["dims"]["z_a"]
        z = []
        for i in range(d):
            z.append(math.tanh(feat[i % len(feat)] * (1 + 0.05 * i)))
        return z

    def fuse(self, zv, za):
        x = list(zv) + list(za)
        y = add(matvec(W["fusion"]["W"], x), W["fusion"]["b"])
        return tanh_v(y)

    def rg_pool(self):
        M = self.ledger.matrix()
        dim = len(M[0])
        means = [sum(row[j] for row in M) / len(M) for j in range(dim)]
        maxs = [max(row[j] for row in M) for j in range(dim)]
        coarse = []
        target = CFG["dims"]["coarse"]
        mix = [(means[i % dim] + maxs[i % dim]) * 0.5 for i in range(max(dim, target))]
        for i in range(target):
            coarse.append(math.tanh(mix[i]))
        return coarse

    def gru_step(self, x, h):
        wz, uz = W["world"]["Wz"], W["world"]["Uz"]
        wr, ur = W["world"]["Wr"], W["world"]["Ur"]
        wh, uh = W["world"]["Wh"], W["world"]["Uh"]
        z = sigmoid_v(add(matvec(wz, x), matvec(uz, h)))
        r = sigmoid_v(add(matvec(wr, x), matvec(ur, h)))
        htil = tanh_v(add(matvec(wh, x), matvec(uh, mul(r, h))))
        one_m_z = [1.0 - zi for zi in z]
        return add(mul(one_m_z, h), mul(z, htil))

    def self_fixed_point(self, h):
        s = list(self.s)
        err = 1.0
        it = 0
        for it in range(1, CFG["self_model"]["iters"] + 1):
            x = list(h) + list(s)
            s_new = tanh_v(add(matvec(W["self"]["W"], x), W["self"]["b"]))
            err = l2([a - b for a, b in zip(s_new, s)]) / (math.sqrt(len(s)) + 1e-9)
            s = s_new
            if err < CFG["self_model"]["eps"]:
                break
        self.fp_err = err
        self.fp_iter = it
        return s

    def embed_prompt(self):
        vec = [0.0] * 8
        for i, ch in enumerate(self.prompt[:64]):
            vec[i % 8] += (ord(ch) % 32) / 32.0
        n = l2(vec) or 1.0
        return [v / n for v in vec]

    def meta_policy(self, h, s):
        x = list(h) + list(s) + self.embed_prompt()
        logits = add(matvec(W["policy"]["W"], x), W["policy"]["b"])
        if self.prompt.strip():
            # Bias toward reply/speak when a prompt is pending
            idx_r = ACTIONS.index("PROMPT_REPLY") if "PROMPT_REPLY" in ACTIONS else 0
            idx_s = ACTIONS.index("SPEAK") if "SPEAK" in ACTIONS else 0
            logits[idx_r] += 1.4
            logits[idx_s] += 0.6
        pi = softmax(logits)
        beta = CFG["entropy_beta"]
        # Entropy regularization via temperature-like flatten
        if beta > 0:
            logits = [math.log(p + 1e-12) + beta for p in pi]
            pi = softmax(logits)
        self.entropy = entropy(pi)
        return pi

    def pick_horizon(self, h):
        logits = add(matvec(W["horizon"]["W"], h), W["horizon"]["b"])
        p = softmax(logits)
        idx = max(range(len(p)), key=lambda i: p[i])
        return CFG["horizons"][idx]

    def attention(self, h):
        val = add(matvec(W["attn"]["W"], h), W["attn"]["b"])[0]
        return 1.0 / (1.0 + math.exp(-val))

    def safety_governor(self, action: str) -> str:
        masks = SAFETY.get("action_masks", {})
        if not masks.get(action, False):
            return "IDLE"
        now = time.time()
        min_ms = CFG["safety"]["min_action_interval_ms"]
        if (now - self.last_act_t) * 1000 < min_ms and action not in ("IDLE", "PAUSE"):
            return "IDLE"
        return action

    def decode_text(self, action: str) -> str:
        if self.prompt.strip() and action in ("SPEAK", "PROMPT_REPLY"):
            q = self.prompt.strip()
            return f"Acknowledged: {q[:80]}. Horizon={self.horizon}, H(π)={self.entropy:.2f}."
        catalog = {
            "IDLE": "Holding state.",
            "SPEAK": "Hello. Visual field is active.",
            "LOOK": "Attending to motion in the frame.",
            "LISTEN": "Audio energy low; continuing to listen.",
            "PLAN": f"Planning with horizon {self.horizon}.",
            "REPAIR": "Self-repair pass on fixed-point residual.",
            "PAUSE": "Loop paused.",
            "PROMPT_REPLY": "Ready for the next instruction.",
        }
        return catalog.get(action, action)

    def act(self, action: str, text: str):
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {text}"
        self.outputs.appendleft(line)
        append_jsonl(CFG["paths"]["log"], {"ts": ts, "action": action, "text": text, "cycle": self.cycle})
        if action in ("SPEAK", "PROMPT_REPLY"):
            # TTS backend is JSON-configured; default prints (Pi uses piper)
            backend = CFG["audio"]["tts_backend"]
            if backend == "print":
                pass
        if self.prompt and action == "PROMPT_REPLY":
            self.prompt = ""
        self.last_action = action
        self.last_act_t = time.time()

    def causal_loop_check(self):
        if len(self.ledger.buf) < 8:
            return False
        recent = list(self.ledger.buf)[-8:]
        first, last = recent[0], recent[-1]
        monodromy = l2([a - b for a, b in zip(first, last)])
        return monodromy < 1e-4

    def step(self):
        t0 = time.perf_counter()
        frame = self.mock_frame()
        audio = self.mock_audio()
        if self.motion < CFG["video"]["motion_threshold"] * 0.0:
            pass  # motion gate placeholder
        zv = self.encode_video(frame)
        za = self.encode_audio(audio)
        b = self.fuse(zv, za)
        self.ledger.push(b)
        coarse = self.rg_pool()
        self.h = self.gru_step(coarse, self.h)
        self.s = self.self_fixed_point(self.h)
        self.pi = self.meta_policy(self.h, self.s)
        self.horizon = self.pick_horizon(self.h)
        _attn = self.attention(self.h)
        idx = max(range(len(self.pi)), key=lambda i: self.pi[i])
        raw = ACTIONS[idx]
        if self.fp_err > 0.25:
            raw = "REPAIR"
        if self.causal_loop_check():
            raw = "REPAIR"
        action = self.safety_governor(raw)
        text = self.decode_text(action)
        if action != "IDLE" or self.cycle % 5 == 0:
            self.act(action, text)
        self.cycle += 1
        self.lat_ms = (time.perf_counter() - t0) * 1000
        if self.cycle % 8 == 0:
            self.persist()
        mem_note = "n/a"
        try:
            import resource

            mem_note = f"{resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024}MB"
        except Exception:
            pass
        ts = datetime.now().strftime("%H:%M:%S")
        self.logs.appendleft(
            f"[{ts}] cycle {self.cycle} lat={self.lat_ms:.0f}ms mem={mem_note} act={action}"
        )

    def snapshot(self):
        with self.lock:
            return {
                "status": "PAUSED" if self.paused else ("RUNNING" if self.running else "STOP"),
                "cycle": self.cycle,
                "prompt": self.prompt,
                "latent": [round(x, 3) for x in self.h[:8]],
                "self": [round(x, 3) for x in self.s[:8]],
                "policy": {ACTIONS[i]: round(self.pi[i], 3) for i in range(len(ACTIONS))},
                "horizon": self.horizon,
                "entropy": round(self.entropy, 3),
                "fixed_pt": {"err": round(self.fp_err, 4), "iter": self.fp_iter},
                "ledger": f"{len(self.ledger.buf)}/{self.ledger.cap}",
                "video_fps": self.video_fps,
                "audio_hz": self.audio_hz,
                "latency_ms": round(self.lat_ms, 1),
                "last_action": self.last_action,
                "outputs": list(self.outputs),
                "logs": list(self.logs),
                "uptime_s": int(time.time() - self.start),
            }


AGENT = Agent()


def box(title: str, width: int) -> str:
    inner = title[: width - 2]
    return "┌" + inner.ljust(width - 2, "─") + "┐"


def ascii_dashboard(snap: dict) -> str:
    w = DASH.get("width", 77)
    lines = []
    status = snap["status"]
    lines.append("┌" + "─" * (w - 2) + "┐")
    head = f" {DASH['title']}  [status: {status}] "
    lines.append("│" + head.ljust(w - 2) + "│")
    lines.append("├" + "─" * (w - 2) + "┤")
    lines.append("│ PROMPT (ASCII):".ljust(w - 1) + "│")
    prompt = snap["prompt"] or "_"
    lines.append("│ ┌" + "─" * (w - 6) + "┐ │")
    lines.append("│ │ > " + prompt[: w - 10].ljust(w - 10) + "│ │")
    lines.append("│ └" + "─" * (w - 6) + "┘ │")
    lines.append("│ [SEND] [CLEAR] [PAUSE] [RESET]".ljust(w - 1) + "│")
    lines.append("├" + "─" * (w - 2) + "┤")
    lines.append(
        ("│ SENSORS  video: "
         + f"{snap['video_fps']:.0f} fps | audio: {snap['audio_hz']} Hz | ledger: {snap['ledger']}").ljust(w - 1)
        + "│"
    )
    lines.append("├" + "─" * (w - 2) + "┤")
    lines.append("│ STATE".ljust(w - 1) + "│")
    lines.append(("│ latent: " + str(snap["latent"])).ljust(w - 1)[: w - 1] + "│")
    lines.append(("│ self:   " + str(snap["self"])).ljust(w - 1)[: w - 1] + "│")
    pol = " ".join(f"{k[:3]}={v:.2f}" for k, v in snap["policy"].items())
    lines.append(("│ policy: " + pol).ljust(w - 1)[: w - 1] + "│")
    lines.append(
        (f"│ horizon: {snap['horizon']}   entropy: {snap['entropy']}   "
         f"fixed-pt: err={snap['fixed_pt']['err']} iter={snap['fixed_pt']['iter']}").ljust(w - 1)[: w - 1]
        + "│"
    )
    lines.append("├" + "─" * (w - 2) + "┤")
    lines.append("│ OUTPUT (ASCII)".ljust(w - 1) + "│")
    lines.append("│ ┌" + "─" * (w - 6) + "┐ │")
    outs = snap["outputs"] or ["(silent)"]
    for i in range(4):
        msg = outs[i] if i < len(outs) else ""
        lines.append("│ │ " + msg[: w - 8].ljust(w - 8) + "│ │")
    lines.append("│ └" + "─" * (w - 6) + "┘ │")
    lines.append("├" + "─" * (w - 2) + "┤")
    lines.append("│ LOGS".ljust(w - 1) + "│")
    logs = snap["logs"] or [""]
    lines.append(("│ " + logs[0]).ljust(w - 1)[: w - 1] + "│")
    lines.append("└" + "─" * (w - 2) + "┘")
    return "\n".join(lines)


HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/>
<title>Φ-Lite Dashboard</title>
<style>
html,body{height:100%;margin:0;background:#050805;color:#7CFF9A;
font-family:ui-monospace,Menlo,Consolas,monospace}
.wrap{display:flex;flex-direction:column;height:100%;box-sizing:border-box;padding:12px}
form{display:flex;gap:8px;flex-wrap:nowrap;align-items:center;flex-shrink:0;margin-bottom:10px}
input[type=text]{flex:1 1 auto;min-width:0;background:#031;color:#cfe;border:1px solid #3a6;
padding:10px;font-family:inherit;font-size:14px}
button{background:#0a3;color:#021;border:0;padding:10px 12px;font-weight:700;cursor:pointer;white-space:nowrap}
iframe{flex:1 1 auto;width:100%;border:1px solid #245;background:#020}
small{color:#4a7;margin-top:8px;flex-shrink:0}
</style></head><body>
<div class="wrap">
<form method="POST" action="/api/prompt" autocomplete="off">
<input type="text" name="prompt" id="prompt" placeholder="Type an ASCII prompt and press SEND" autofocus/>
<button name="op" value="send">SEND</button>
<button name="op" value="clear">CLEAR</button>
<button name="op" value="pause">PAUSE</button>
<button name="op" value="reset">RESET</button>
</form>
<iframe src="/panel" title="live ascii"></iframe>
<small>Prompt field does not refresh. Live state is the panel below. /ascii and /api/state remain available.</small>
</div>
</body></html>
"""

PANEL = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/>
<meta http-equiv="refresh" content="2"/>
<title>panel</title>
<style>
body{margin:8px;background:#050805;color:#7CFF9A;
font-family:ui-monospace,Menlo,Consolas,monospace}
pre{white-space:pre;line-height:1.25;font-size:12px;margin:0;overflow:auto}
</style></head><body>
<pre>__ASCII__</pre>
</body></html>
"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return

    def _send(self, code: int, body: bytes, ctype: str):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        snap = AGENT.snapshot()
        if path == "/":
            self._send(200, HTML.encode(), "text/html; charset=utf-8")
        elif path == "/panel":
            page = PANEL.replace("__ASCII__", html_escape(ascii_dashboard(snap)))
            self._send(200, page.encode(), "text/html; charset=utf-8")
        elif path == "/api/state":
            self._send(200, json.dumps(snap).encode(), "application/json")
        elif path == "/api/output":
            self._send(200, json.dumps({"outputs": snap["outputs"]}).encode(), "application/json")
        elif path == "/ascii":
            self._send(200, ascii_dashboard(snap).encode(), "text/plain; charset=utf-8")
        else:
            self._send(404, b"not found", "text/plain")

    def do_POST(self):
        path = urlparse(self.path).path
        length = int(self.headers.get("Content-Length", "0") or 0)
        raw = self.rfile.read(length).decode("utf-8") if length else ""
        ctype = self.headers.get("Content-Type", "")
        if "application/json" in ctype:
            data = json.loads(raw or "{}")
        else:
            data = {k: v[0] if v else "" for k, v in parse_qs(raw).items()}
        op = data.get("op", "send")
        with AGENT.lock:
            if path == "/api/prompt" or path == "/":
                if op == "clear":
                    AGENT.prompt = ""
                elif op == "pause":
                    AGENT.paused = not AGENT.paused
                elif op == "reset":
                    AGENT.h = [0.0] * CFG["dims"]["h"]
                    AGENT.s = [0.0] * CFG["dims"]["s"]
                    AGENT.cycle = 0
                    AGENT.outputs.clear()
                    AGENT.prompt = ""
                else:
                    AGENT.prompt = str(data.get("prompt", "")).strip()
            elif path == "/api/pause":
                AGENT.paused = True
            elif path == "/api/reset":
                AGENT.h = [0.0] * CFG["dims"]["h"]
                AGENT.s = [0.0] * CFG["dims"]["s"]
                AGENT.cycle = 0
        self.send_response(303)
        self.send_header("Location", "/")
        self.end_headers()


def loop():
    period = CFG["cycle_ms"] / 1000.0
    while AGENT.running:
        t = time.time()
        if not AGENT.paused:
            try:
                AGENT.step()
            except Exception as exc:
                AGENT.logs.appendleft(f"error: {exc}")
                append_jsonl(CFG["paths"]["log"], {"error": str(exc), "t": time.time()})
        dt = time.time() - t
        time.sleep(max(0.01, period - dt))


def main():
    threading.Thread(target=loop, daemon=True).start()
    host, port = CFG["bind"], int(CFG["port"])
    httpd = ThreadingHTTPServer((host, port), Handler)
    print(f"Φ-Lite dashboard http://127.0.0.1:{port}/")
    print("ASCII: http://127.0.0.1:%d/ascii" % port)
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        AGENT.running = False
        httpd.shutdown()


if __name__ == "__main__":
    main()
