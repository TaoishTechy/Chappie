#!/usr/bin/env python3
"""Φ-Lite Production v0.5 — single-file runtime.

Adds metric dumps, rotation, online Hebbian/PE updates, recursive confidence,
error-state repair that mutates W, collapse-breaking control, wired detectors,
watchdog, and localhost bind.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import random
import signal
import threading
import time
from collections import deque
from datetime import datetime
from html import escape as html_escape
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

try:
    import numpy as np
except ImportError:  # pragma: no cover
    np = None

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
VERSION = "0.5.0"


def load_json(name: str, default=None):
    path = ROOT / name
    if not path.exists():
        return default if default is not None else {}
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_json(name: str, data) -> None:
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")
    tmp.replace(path)


def rotate_if_needed(path: Path, cap: int) -> None:
    if not path.exists() or cap <= 0:
        return
    try:
        n = sum(1 for _ in path.open("r", encoding="utf-8"))
    except OSError:
        return
    if n < cap:
        return
    prev = path.with_suffix(path.suffix + ".prev")
    try:
        if prev.exists():
            prev.unlink()
        path.replace(prev)
    except OSError:
        pass


def append_jsonl(name: str, rec: dict, rotate=True) -> str | None:
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    cap = int(CFG.get("rotate_lines", 2000))
    try:
        if rotate:
            rotate_if_needed(path, cap)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, separators=(",", ":")) + "\n")
        return None
    except OSError as exc:
        return f"{type(exc).__name__}:{exc}"


CFG = load_json("config.json")
ARCH = load_json("architecture.json")
SAFETY = load_json("safety.json")
DASH = load_json("dashboard.json")
DET = load_json("metrics/detectors.json")
TH = (DET or {}).get("thresholds", {})
ACTIONS = ARCH.get("actions", ["IDLE", "SPEAK"])


def rng_matrix(rows: int, cols: int, seed: int) -> list:
    rnd = random.Random(seed)
    scale = 1.0 / math.sqrt(max(cols, 1))
    return [[(rnd.random() * 2 - 1) * scale for _ in range(cols)] for _ in range(rows)]


def ensure_weights() -> dict:
    w = load_json(CFG["paths"]["weights"], None)
    if w and "fusion" in w:
        w.setdefault("version", VERSION)
        w.setdefault("updates", 0)
        need = CFG["dims"]["h"] + CFG["dims"]["s"] + 16
        pw = w.get("policy", {}).get("W")
        if not pw or len(pw[0]) != need:
            w["policy"] = {
                "W": rng_matrix(len(ACTIONS), need, 9),
                "b": [0.0] * len(ACTIONS),
            }
        if "conf" not in w:
            w["conf"] = {"W": rng_matrix(1, CFG["dims"]["h"] + 4, 12), "b": [0.0]}
        return w
    d = CFG["dims"]
    w = {
        "note": "v0.5 weights; mutated online when learn.enabled",
        "version": VERSION,
        "updates": 0,
        "fusion": {"W": rng_matrix(d["b"], d["z_v"] + d["z_a"], 1), "b": [0.0] * d["b"]},
        "world": {
            "Wz": rng_matrix(d["h"], d["coarse"], 2),
            "Uz": rng_matrix(d["h"], d["h"], 3),
            "Wr": rng_matrix(d["h"], d["coarse"], 4),
            "Ur": rng_matrix(d["h"], d["h"], 5),
            "Wh": rng_matrix(d["h"], d["coarse"], 6),
            "Uh": rng_matrix(d["h"], d["h"], 7),
        },
        "self": {"W": rng_matrix(d["s"], d["h"] + d["s"], 8), "b": [0.0] * d["s"]},
        "policy": {
            "W": rng_matrix(len(ACTIONS), d["h"] + d["s"] + 16, 9),
            "b": [0.0] * len(ACTIONS),
        },
        "attn": {"W": rng_matrix(1, d["h"], 10), "b": [0.0]},
        "horizon": {"W": rng_matrix(len(CFG["horizons"]), d["h"], 11), "b": [0.0] * len(CFG["horizons"])},
        "conf": {"W": rng_matrix(1, d["h"] + 4, 12), "b": [0.0]},
    }
    save_json(CFG["paths"]["weights"], w)
    return w


W = ensure_weights()


def weights_sha1() -> str:
    raw = json.dumps({"u": W.get("updates", 0), "b": W["policy"]["b"][:8]}, separators=(",", ":"))
    return hashlib.sha1(raw.encode()).hexdigest()[:16]


def matvec(Wmat, x):
    if np is not None:
        return (np.asarray(Wmat, dtype=float) @ np.asarray(x, dtype=float)).tolist()
    return [sum(a * b for a, b in zip(row, x)) for row in Wmat]


def tanh_v(xs):
    return [math.tanh(v) for v in xs]


def sigmoid_v(xs):
    out = []
    for v in xs:
        v = max(-20.0, min(20.0, v))
        out.append(1.0 / (1.0 + math.exp(-v)))
    return out


def softmax(xs):
    m = max(xs)
    ex = [math.exp(v - m) for v in xs]
    s = sum(ex) or 1.0
    return [v / s for v in ex]


def add(a, b):
    return [x + y for x, y in zip(a, b)]


def mul(a, b):
    return [x * y for x, y in zip(a, b)]


def l2(a):
    return math.sqrt(sum(x * x for x in a))


def entropy(p):
    return -sum(q * math.log(q + 1e-12) for q in p)


def emit_event(typ: str, **payload):
    rec = {"type": typ, "t": time.time(), **payload}
    append_jsonl(CFG["paths"]["events"], rec)


class Ledger:
    def __init__(self, cap: int, dim: int):
        self.cap = cap
        self.dim = dim
        self.buf = deque(maxlen=cap)
        self._load()

    def _load(self):
        path = ROOT / CFG["paths"]["ledger"]
        if not path.exists():
            return
        try:
            lines = path.read_text(encoding="utf-8").splitlines()[-self.cap :]
        except OSError:
            return
        for line in lines:
            try:
                rec = json.loads(line)
                self.buf.append(rec["b"])
            except Exception:
                continue

    def push(self, b):
        self.buf.append(list(b))
        compact = [round(x, 4) for x in b]
        return append_jsonl(CFG["paths"]["ledger"], {"t": round(time.time(), 4), "b": compact})

    def matrix(self):
        return list(self.buf) if self.buf else [[0.0] * self.dim]

    def centroid(self):
        M = self.matrix()
        n = len(M)
        d = len(M[0])
        return [sum(row[j] for row in M) / n for j in range(d)]


class Agent:
    def __init__(self):
        self.lock = threading.Lock()
        self.running = True
        self.paused = False
        self.cycle = 0
        self.prompt = ""
        self.outputs = deque(maxlen=8)
        self.logs = deque(maxlen=8)
        self.recent_events = deque(maxlen=8)
        self.h = [0.0] * CFG["dims"]["h"]
        self.s = [0.0] * CFG["dims"]["s"]
        self.E = [0.0] * CFG["dims"]["E"]
        self.c = 0.5
        self.attn = 0.5
        self.pi = [1.0 / len(ACTIONS)] * len(ACTIONS)
        self.horizon = 5
        self.entropy = math.log(len(ACTIONS))
        self.fp_err = 0.0
        self.fp_iter = 0
        self.last_action = "IDLE"
        self.last_act_t = 0.0
        self.lat_ms = 0.0
        self.video_fps = 0.0
        self.audio_hz = CFG["audio"]["sample_rate"]
        self.motion = 0.0
        self.prev_frame = None
        self.prev_b = None
        self.ledger = Ledger(CFG["ledger"]["capacity"], CFG["ledger"]["dim"])
        self.start = time.time()
        self.action_hist = deque(maxlen=64)
        self.horizon_hist = deque(maxlen=64)
        self.entropy_hist = deque(maxlen=64)
        self.fp_hist = deque(maxlen=16)
        self.skip_heavy = False
        self.last_io_error = None
        self.pred_err = 0.0
        self.novelty_b = 0.0
        self.novelty_mu = 0.0
        self.novelty_m2 = 0.0
        self.novelty_n = 0
        self.horizon_counts = [1] * len(CFG["horizons"])
        self._restore()

    def _restore(self):
        st = load_json(CFG["paths"]["state"], {})
        if st.get("schema") not in (None, "0.5"):
            pass
        self.cycle = int(st.get("cycle", 0))
        self.prompt = st.get("prompt", "")
        if st.get("h") and len(st["h"]) == len(self.h):
            self.h = st["h"]
        if st.get("s") and len(st["s"]) == len(self.s):
            self.s = st["s"]
        if st.get("E") and len(st["E"]) == len(self.E):
            self.E = st["E"]
        if "c" in st:
            self.c = float(st["c"])

    def persist(self):
        save_json(
            CFG["paths"]["state"],
            {
                "schema": "0.5",
                "version": VERSION,
                "cycle": self.cycle,
                "prompt": self.prompt,
                "h": [round(x, 5) for x in self.h],
                "s": [round(x, 5) for x in self.s],
                "E": [round(x, 5) for x in self.E],
                "c": round(self.c, 5),
                "fp_err": round(self.fp_err, 5),
                "fp_iter": self.fp_iter,
                "last_action": self.last_action,
                "ts": time.time(),
            },
        )

    def persist_weights(self):
        W["updates"] = int(W.get("updates", 0)) + 1
        W["version"] = VERSION
        save_json(CFG["paths"]["weights"], W)

    def mock_frame(self):
        w, h = CFG["video"]["width"], CFG["video"]["height"]
        t = time.time()
        return {
            "w": w,
            "h": h,
            "cx": 0.5 + 0.3 * math.sin(t * 0.7),
            "cy": 0.5 + 0.3 * math.cos(t * 0.5),
            "t": t,
        }

    def mock_audio(self):
        t = time.time()
        return [0.1 + 0.05 * math.sin(t), math.sin(t * 2), math.cos(t * 1.3), 0.02]

    def encode_video(self, frame):
        d = CFG["dims"]["z_v"]
        base = [frame["cx"], frame["cy"], math.sin(frame["t"]), math.cos(frame["t"])]
        z = [math.tanh(base[i % 4] * (1 + 0.07 * i) + 0.01 * i) for i in range(d)]
        if self.prev_frame:
            self.motion = abs(frame["cx"] - self.prev_frame["cx"]) + abs(
                frame["cy"] - self.prev_frame["cy"]
            )
        self.prev_frame = frame
        self.video_fps = CFG["video"]["fps"]
        return z

    def encode_audio(self, feat):
        d = CFG["dims"]["z_a"]
        return [math.tanh(feat[i % len(feat)] * (1 + 0.05 * i)) for i in range(d)]

    def fuse(self, zv, za):
        x = list(zv) + list(za)
        y = add(matvec(W["fusion"]["W"], x), W["fusion"]["b"])
        return tanh_v(y)

    def rg_pool(self):
        M = self.ledger.matrix()
        dim = len(M[0])
        n = len(M)
        # recency weights
        wts = [0.5 + 0.5 * (i + 1) / n for i in range(n)]
        sw = sum(wts)
        means = [sum(M[i][j] * wts[i] for i in range(n)) / sw for j in range(dim)]
        maxs = [max(row[j] for row in M) for j in range(dim)]
        target = CFG["dims"]["coarse"]
        mix = [(means[i % dim] + maxs[i % dim]) * 0.5 for i in range(max(dim, target))]
        return [math.tanh(mix[i]) for i in range(target)]

    def gru_step(self, x, h):
        wz, uz = W["world"]["Wz"], W["world"]["Uz"]
        wr, ur = W["world"]["Wr"], W["world"]["Ur"]
        wh, uh = W["world"]["Wh"], W["world"]["Uh"]
        z = sigmoid_v(add(matvec(wz, x), matvec(uz, h)))
        r = sigmoid_v(add(matvec(wr, x), matvec(ur, h)))
        htil = tanh_v(add(matvec(wh, x), matvec(uh, mul(r, h))))
        one_m_z = [1.0 - zi for zi in z]
        h_new = add(mul(one_m_z, h), mul(z, htil))
        # precision-weighted prediction error toward coarse x padded
        pe = []
        for i, hi in enumerate(h_new):
            tgt = x[i] if i < len(x) else 0.0
            pe.append(tgt - hi)
        gain = 0.05 * (0.5 + self.c)
        h_new = [h_new[i] + gain * pe[i] for i in range(len(h_new))]
        self.pred_err = l2(pe) / (math.sqrt(len(pe)) + 1e-9)
        return h_new

    def self_fixed_point(self, h):
        s = list(self.s)
        err = 1.0
        it = 0
        for it in range(1, CFG["self_model"]["iters"] + 1):
            x = list(h) + list(s)
            s_new = tanh_v(add(matvec(W["self"]["W"], x), W["self"]["b"]))
            err = l2([a - b for a, b in zip(s_new, s)]) / (math.sqrt(len(s)) + 1e-9)
            s = s_new
            if err < CFG["self_model"]["eps"]:
                break
        self.fp_err = err
        self.fp_iter = it
        self.fp_hist.append(err)
        return s

    def embed_prompt(self):
        vec = [0.0] * 16
        p = self.prompt[:256]
        for i, ch in enumerate(p):
            vec[i % 16] += (ord(ch) % 97) / 97.0
        vec[0] += 1.0 if p else 0.0
        n = l2(vec)
        if n < 1e-9:
            return vec
        return [v / n for v in vec]

    def attention(self, h):
        val = add(matvec(W["attn"]["W"], h), W["attn"]["b"])[0]
        a = 1.0 / (1.0 + math.exp(-val))
        a = 0.5 * a + 0.5 * min(1.0, self.novelty_b / (self.novelty_mu + 1e-3 + 1.0))
        return max(0.05, min(1.0, a))

    def update_confidence(self):
        feat = list(self.h[: CFG["dims"]["h"]])[: CFG["dims"]["h"]]
        extra = [self.fp_err, self.pred_err, self.entropy / 3.0, 1.0 if self.prompt else 0.0]
        x = feat + extra
        # conf head expects h+4; truncate/pad
        need = CFG["dims"]["h"] + 4
        if len(x) < need:
            x = x + [0.0] * (need - len(x))
        else:
            x = x[:need]
        raw = add(matvec(W["conf"]["W"], x), W["conf"]["b"])[0]
        meas = 1.0 / (1.0 + math.exp(-raw))
        e = 1.0 - min(1.0, self.fp_err + self.pred_err)
        self.c = 0.7 * self.c + 0.2 * meas + 0.1 * e
        self.c = max(0.02, min(0.98, self.c))
        return self.c

    def meta_policy(self, h, s):
        x = list(h) + list(s) + self.embed_prompt()
        logits = add(matvec(W["policy"]["W"], x), W["policy"]["b"])
        if self.prompt.strip():
            logits[ACTIONS.index("PROMPT_REPLY")] += 2.2
            logits[ACTIONS.index("SPEAK")] += 1.0
        # repetition cost
        if self.action_hist:
            last = self.action_hist[-1]
            if last in ACTIONS:
                logits[ACTIONS.index(last)] -= CFG.get("repeat_penalty", 0.55)
        # free-energy-ish: prefer high entropy when confidence low
        T = max(0.35, CFG.get("entropy_beta", 0.35) + (1.0 - self.c))
        logits = [v / T for v in logits]
        # MDL-ish L1 on magnitude
        logits = [v - 0.02 * abs(v) for v in logits]
        pi = softmax(logits)
        if random.random() < CFG.get("epsilon", 0.12):
            j = random.randrange(len(ACTIONS))
            pi = [0.02] * len(ACTIONS)
            pi[j] = 1.0 - 0.02 * (len(ACTIONS) - 1)
            pi = softmax([math.log(p) for p in pi])
        self.entropy = entropy(pi)
        self.entropy_hist.append(self.entropy)
        return pi

    def pick_horizon(self, h):
        logits = add(matvec(W["horizon"]["W"], h), W["horizon"]["b"])
        # novelty and uncertainty lengthen horizon
        z = 0.0
        if self.novelty_n > 8:
            sd = math.sqrt(max(self.novelty_m2 / self.novelty_n, 1e-9))
            z = (self.novelty_b - self.novelty_mu) / sd
        boost = [0.0, 0.15 * z, 0.25 * z, 0.35 * z]
        logits = [logits[i] + boost[i] + 0.05 * math.log(self.horizon_counts[i]) for i in range(4)]
        p = softmax(logits)
        # Thompson-like sample
        r = random.random()
        acc = 0.0
        idx = len(p) - 1
        for i, pi in enumerate(p):
            acc += pi
            if r <= acc:
                idx = i
                break
        self.horizon_counts[idx] += 1
        H = CFG["horizons"][idx]
        if self.horizon_hist and H != self.horizon_hist[-1]:
            emit_event("HORIZON_SHIFT", prev=self.horizon_hist[-1], H=H, novelty_z=round(z, 3))
        self.horizon_hist.append(H)
        if len(self.horizon_hist) >= 32:
            share = self.horizon_hist.count(H) / len(self.horizon_hist)
            if share >= TH.get("horizon_stick_share", 0.9):
                emit_event("HORIZON_STICK", H=H, share=round(share, 4), window=len(self.horizon_hist))
        return H

    def safety_governor(self, action: str) -> str:
        masks = SAFETY.get("action_masks", {})
        if not masks.get(action, False):
            emit_event("SAFETY_MASK", action=action)
            return "IDLE"
        now = time.time()
        min_ms = CFG["safety"]["min_action_interval_ms"]
        if (now - self.last_act_t) * 1000 < min_ms and action not in ("IDLE", "PAUSE"):
            return "IDLE"
        return action

    def decode_text(self, action: str) -> str:
        if self.prompt.strip() and action in ("SPEAK", "PROMPT_REPLY"):
            q = self.prompt.strip()
            return f"Acknowledged: {q[:80]}. H={self.horizon} Hπ={self.entropy:.2f} c={self.c:.2f}."
        catalog = {
            "IDLE": "Holding state.",
            "SPEAK": "Hello. Visual field is active.",
            "LOOK": "Attending to motion in the frame.",
            "LISTEN": "Audio energy low; continuing to listen.",
            "PLAN": f"Planning with horizon {self.horizon}.",
            "REPAIR": f"Self-repair: E={l2(self.E):.3f} fp={self.fp_err:.3f}.",
            "PAUSE": "Loop paused.",
            "PROMPT_REPLY": "Ready for the next instruction.",
        }
        return catalog.get(action, action)

    def hebbian_policy(self, x, action_idx, pred_err):
        if not CFG.get("learn", {}).get("enabled", False):
            return
        lr = float(CFG["learn"]["lr"]) * (0.3 + pred_err)
        # nudge chosen action down if error high, up if low
        sign = -1.0 if pred_err > 0.15 else 1.0
        row = W["policy"]["W"][action_idx]
        for j in range(min(len(row), len(x))):
            row[j] += lr * sign * x[j] * 0.05
            row[j] = max(-1.5, min(1.5, row[j]))
        W["policy"]["b"][action_idx] += lr * sign * 0.02

    def repair(self):
        before = weights_sha1()
        e_before = l2(self.E)
        # descend on E and jitter self/policy bias
        lr = 0.08
        self.E = [e * (1.0 - lr) + self.fp_err * 0.1 for e in self.E]
        self.E[self.cycle % len(self.E)] = self.fp_err
        if CFG.get("learn", {}).get("enabled", False):
            for i in range(len(W["self"]["b"])):
                W["self"]["b"][i] -= 0.01 * self.fp_err * (1 if i % 2 == 0 else -1)
            W["updates"] = int(W.get("updates", 0))
            after = weights_sha1()
            # force a visible mutation via updates counter on persist
            self.persist_weights()
            after = weights_sha1()
            emit_event(
                "WEIGHT_MUTATION",
                before=before,
                after=after,
                e_before=round(e_before, 4),
                e_after=round(l2(self.E), 4),
                fp=round(self.fp_err, 4),
            )
        else:
            emit_event("REPAIR_NOOP", fp=round(self.fp_err, 4))

    def act(self, action: str, text: str):
        ts = datetime.now().strftime("%H:%M:%S")
        line = f"[{ts}] {text}"
        self.outputs.appendleft(line)
        append_jsonl(
            CFG["paths"]["log"],
            {"ts": ts, "action": action, "text": text, "cycle": self.cycle, "c": round(self.c, 3)},
        )
        if self.prompt and action == "PROMPT_REPLY":
            emit_event("PROMPT_CONSUMED", cycle=self.cycle, text=text)
            self.prompt = ""
        if self.action_hist and action != self.action_hist[-1]:
            emit_event("ACTION_INNOVATION", prev=self.action_hist[-1], action=action, cycle=self.cycle)
        self.action_hist.append(action)
        self.last_action = action
        self.last_act_t = time.time()

    def causal_loop_check(self):
        if len(self.ledger.buf) < 8:
            return False
        recent = list(self.ledger.buf)[-8:]
        # holonomy proxy: product of successive cosines around the loop
        acc = 1.0
        for i in range(len(recent) - 1):
            a, b = recent[i], recent[i + 1]
            na, nb = l2(a) or 1.0, l2(b) or 1.0
            acc *= sum(x * y for x, y in zip(a, b)) / (na * nb)
        first, last = recent[0], recent[-1]
        nf, nl = l2(first) or 1.0, l2(last) or 1.0
        close = abs(sum(x * y for x, y in zip(first, last)) / (nf * nl) - acc)
        hit = close < TH.get("monodromy", 1e-4) and l2([a - b for a, b in zip(first, last)]) < 0.02
        if hit:
            emit_event("MONODROMY_HIT", close=round(close, 6))
        return hit

    def update_novelty(self, b):
        c = self.ledger.centroid()
        self.novelty_b = l2([b[i] - c[i] for i in range(len(b))])
        self.novelty_n += 1
        d = self.novelty_b - self.novelty_mu
        self.novelty_mu += d / self.novelty_n
        self.novelty_m2 += d * (self.novelty_b - self.novelty_mu)
        if self.novelty_n > 16:
            sd = math.sqrt(max(self.novelty_m2 / self.novelty_n, 1e-9))
            z = (self.novelty_b - self.novelty_mu) / sd
            if z >= TH.get("novelty_z", 3.0):
                emit_event("NOVEL_BOUNDARY", z=round(z, 3), cycle=self.cycle)

    def dump_metric(self, action, io_err):
        ranked = sorted(self.pi, reverse=True)
        margin = ranked[0] - ranked[1] if len(ranked) > 1 else ranked[0]
        rec = {
            "t": round(time.time(), 4),
            "cycle": self.cycle,
            "dt_ms": round(self.lat_ms, 2),
            "action": action,
            "H_pi": round(self.entropy, 4),
            "argmax_margin": round(margin, 4),
            "horizon": self.horizon,
            "fp_err": round(self.fp_err, 4),
            "fp_iter": self.fp_iter,
            "attn": round(self.attn, 4),
            "c": round(self.c, 4),
            "ledger_n": len(self.ledger.buf),
            "b_l2": None if not self.ledger.buf else round(l2(self.ledger.buf[-1]), 4),
            "h_l2": round(l2(self.h), 4),
            "s_l2": round(l2(self.s), 4),
            "E_l2": round(l2(self.E), 4),
            "novelty_b": round(self.novelty_b, 4),
            "pred_err": round(self.pred_err, 4),
            "prompt_pending": bool(self.prompt),
            "io_error": io_err,
            "weights_sha1": weights_sha1(),
        }
        err = append_jsonl(CFG["paths"]["metrics"], rec)
        if err:
            emit_event("IO_FAULT", op="metrics", detail=err)
        if self.entropy_hist:
            if self.entropy <= TH.get("entropy_low", 0.6):
                emit_event("ENTROPY_DROP", H_pi=round(self.entropy, 4), cycle=self.cycle)
            if self.entropy >= TH.get("entropy_high", 2.05):
                emit_event("ENTROPY_SPIKE", H_pi=round(self.entropy, 4), cycle=self.cycle)
        if len(self.action_hist) >= 32:
            share = self.action_hist.count(action) / len(self.action_hist)
            if share >= TH.get("mode_collapse_share", 0.85):
                emit_event(
                    "MODE_COLLAPSE",
                    action=action,
                    share=round(share, 4),
                    window=len(self.action_hist),
                    threshold=TH.get("mode_collapse_share", 0.85),
                )
        if len(self.fp_hist) >= TH.get("fp_stuck_min_cycles", 8):
            if all(e > TH.get("fp_err_repair", 0.25) for e in list(self.fp_hist)[-8:]):
                emit_event("FP_STUCK", fp=round(self.fp_err, 4))

    def step(self):
        t0 = time.perf_counter()
        io_err = None
        frame = self.mock_frame()
        audio = self.mock_audio()
        zv = self.encode_video(frame)
        if self.motion < CFG["video"]["motion_threshold"] and self.prev_b is not None:
            # motion gate: reuse last visual code
            pass
        za = self.encode_audio(audio)
        b = self.fuse(zv, za)
        self.update_novelty(b)
        io_err = self.ledger.push(b) or io_err
        if io_err:
            emit_event("IO_FAULT", op="ledger", detail=io_err)
            self.last_io_error = io_err
        coarse = self.rg_pool()
        if self.skip_heavy:
            self.skip_heavy = False
        else:
            self.h = self.gru_step(coarse, self.h)
            self.s = self.self_fixed_point(self.h)
        self.attn = self.attention(self.h)
        self.update_confidence()
        if self.attn < 0.12:
            coarse = [v * self.attn for v in coarse]
        self.pi = self.meta_policy(self.h, self.s)
        self.horizon = self.pick_horizon(self.h)
        idx = max(range(len(self.pi)), key=lambda i: self.pi[i])
        raw = ACTIONS[idx]
        if self.fp_err > 0.25 or self.causal_loop_check():
            raw = "REPAIR"
        action = self.safety_governor(raw)
        if action == "REPAIR":
            self.repair()
        xpol = list(self.h) + list(self.s) + self.embed_prompt()
        self.hebbian_policy(xpol, ACTIONS.index(action) if action in ACTIONS else 0, self.pred_err)
        text = self.decode_text(action)
        if action != "IDLE" or self.cycle % 5 == 0:
            self.act(action, text)
        else:
            self.action_hist.append(action)
            self.last_action = action
        self.prev_b = b
        self.cycle += 1
        self.lat_ms = (time.perf_counter() - t0) * 1000
        if self.lat_ms > CFG["safety"]["watchdog_ms"]:
            emit_event("DT_GAP", dt_ms=round(self.lat_ms, 1), cycle=self.cycle)
            self.skip_heavy = True
        if self.cycle % 8 == 0:
            self.persist()
        if CFG["learn"]["enabled"] and self.cycle % CFG["learn"]["persist_every"] == 0:
            try:
                self.persist_weights()
                emit_event("WEIGHT_MUTATION", sha1=weights_sha1(), updates=W.get("updates"), cycle=self.cycle)
            except OSError as exc:
                emit_event("IO_FAULT", op="weights", detail=str(exc))
        self.dump_metric(action, io_err)
        ts = datetime.now().strftime("%H:%M:%S")
        self.logs.appendleft(
            f"[{ts}] cyc {self.cycle} {action} Hπ={self.entropy:.2f} c={self.c:.2f} lat={self.lat_ms:.0f}ms"
        )

    def snapshot(self):
        with self.lock:
            return {
                "version": VERSION,
                "status": "PAUSED" if self.paused else ("RUNNING" if self.running else "STOP"),
                "cycle": self.cycle,
                "prompt": self.prompt,
                "latent": [round(x, 3) for x in self.h[:8]],
                "self": [round(x, 3) for x in self.s[:8]],
                "policy": {ACTIONS[i]: round(self.pi[i], 3) for i in range(len(ACTIONS))},
                "horizon": self.horizon,
                "entropy": round(self.entropy, 3),
                "c": round(self.c, 3),
                "attn": round(self.attn, 3),
                "fixed_pt": {"err": round(self.fp_err, 4), "iter": self.fp_iter},
                "ledger": f"{len(self.ledger.buf)}/{self.ledger.cap}",
                "video_fps": self.video_fps,
                "audio_hz": self.audio_hz,
                "latency_ms": round(self.lat_ms, 1),
                "last_action": self.last_action,
                "outputs": list(self.outputs),
                "logs": list(self.logs),
                "uptime_s": int(time.time() - self.start),
                "weights_sha1": weights_sha1(),
            }


AGENT = Agent()


def ascii_dashboard(snap: dict) -> str:
    w = DASH.get("width", 77)
    lines = []
    lines.append("┌" + "─" * (w - 2) + "┐")
    head = f" {DASH['title']} v{snap.get('version','')}  [{snap['status']}] "
    lines.append("│" + head.ljust(w - 2)[: w - 2] + "│")
    lines.append("├" + "─" * (w - 2) + "┤")
    lines.append("│ PROMPT (type in the field above; panel below refreshes)".ljust(w - 1)[: w - 1] + "│")
    lines.append("├" + "─" * (w - 2) + "┤")
    lines.append(
        (
            f"│ SENSORS  video:{snap['video_fps']:.0f}fps audio:{snap['audio_hz']}Hz "
            f"ledger:{snap['ledger']}"
        ).ljust(w - 1)[: w - 1]
        + "│"
    )
    lines.append("├" + "─" * (w - 2) + "┤")
    lines.append(
        (
            f"│ STATE c={snap.get('c')} attn={snap.get('attn')} Hπ={snap['entropy']} "
            f"H={snap['horizon']} fp={snap['fixed_pt']['err']}"
        ).ljust(w - 1)[: w - 1]
        + "│"
    )
    lines.append(("│ latent: " + str(snap["latent"])).ljust(w - 1)[: w - 1] + "│")
    pol = " ".join(f"{k[:3]}={v:.2f}" for k, v in snap["policy"].items())
    lines.append(("│ policy: " + pol).ljust(w - 1)[: w - 1] + "│")
    lines.append("├" + "─" * (w - 2) + "┤")
    lines.append("│ OUTPUT".ljust(w - 1)[: w - 1] + "│")
    outs = snap["outputs"] or ["(silent)"]
    for i in range(4):
        msg = outs[i] if i < len(outs) else ""
        lines.append(("│ " + msg).ljust(w - 1)[: w - 1] + "│")
    lines.append("├" + "─" * (w - 2) + "┤")
    logs = snap["logs"] or [""]
    lines.append(("│ " + logs[0]).ljust(w - 1)[: w - 1] + "│")
    lines.append("└" + "─" * (w - 2) + "┘")
    return "\n".join(lines)


HTML = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/>
<title>Φ-Lite Dashboard</title>
<style>
html,body{height:100%;margin:0;background:#050805;color:#7CFF9A;
font-family:ui-monospace,Menlo,Consolas,monospace}
.wrap{display:flex;flex-direction:column;height:100%;box-sizing:border-box;padding:12px}
form{display:flex;gap:8px;flex-wrap:nowrap;align-items:center;flex-shrink:0;margin-bottom:10px}
input[type=text]{flex:1 1 auto;min-width:0;background:#031;color:#cfe;border:1px solid #3a6;
padding:10px;font-family:inherit;font-size:14px}
button{background:#0a3;color:#021;border:0;padding:10px 12px;font-weight:700;cursor:pointer;white-space:nowrap}
iframe{flex:1 1 auto;width:100%;border:1px solid #245;background:#020}
small{color:#4a7;margin-top:8px;flex-shrink:0}
</style></head><body>
<div class="wrap">
<form method="POST" action="/api/prompt" autocomplete="off">
<input type="text" name="prompt" id="prompt" placeholder="Type an ASCII prompt and press SEND" autofocus maxlength="512"/>
<button name="op" value="send">SEND</button>
<button name="op" value="clear">CLEAR</button>
<button name="op" value="pause">PAUSE</button>
<button name="op" value="reset">RESET</button>
</form>
<iframe src="/panel" title="live ascii"></iframe>
<small>Φ-Lite v0.5 — prompt field does not refresh. Bind 127.0.0.1. Metrics: /metrics/metrics.jsonl</small>
</div>
</body></html>
"""

PANEL = """<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"/>
<meta http-equiv="refresh" content="2"/>
<title>panel</title>
<style>
body{margin:8px;background:#050805;color:#7CFF9A;
font-family:ui-monospace,Menlo,Consolas,monospace}
pre{white-space:pre;line-height:1.25;font-size:12px;margin:0;overflow:auto}
</style></head><body>
<pre>__ASCII__</pre>
</body></html>
"""


class Handler(BaseHTTPRequestHandler):
    def log_message(self, fmt, *args):
        return

    def _send(self, code: int, body: bytes, ctype: str):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlparse(self.path).path
        snap = AGENT.snapshot()
        if path == "/":
            self._send(200, HTML.encode(), "text/html; charset=utf-8")
        elif path == "/panel":
            page = PANEL.replace("__ASCII__", html_escape(ascii_dashboard(snap)))
            self._send(200, page.encode(), "text/html; charset=utf-8")
        elif path == "/api/state":
            self._send(200, json.dumps(snap).encode(), "application/json")
        elif path == "/api/output":
            self._send(200, json.dumps({"outputs": snap["outputs"]}).encode(), "application/json")
        elif path == "/ascii":
            self._send(200, ascii_dashboard(snap).encode(), "text/plain; charset=utf-8")
        else:
            self._send(404, b"not found", "text/plain")

    def do_POST(self):
        path = urlparse(self.path).path
        length = int(self.headers.get("Content-Length", "0") or 0)
        cap = int(CFG["safety"].get("max_prompt_bytes", 4096))
        if length > cap:
            self._send(413, b"payload too large", "text/plain")
            return
        raw = self.rfile.read(length).decode("utf-8") if length else ""
        ctype = self.headers.get("Content-Type", "")
        if "application/json" in ctype:
            data = json.loads(raw or "{}")
        else:
            data = {k: v[0] if v else "" for k, v in parse_qs(raw).items()}
        op = data.get("op", "send")
        with AGENT.lock:
            if path in ("/api/prompt", "/"):
                if op == "clear":
                    AGENT.prompt = ""
                elif op == "pause":
                    AGENT.paused = not AGENT.paused
                elif op == "reset":
                    AGENT.h = [0.0] * CFG["dims"]["h"]
                    AGENT.s = [0.0] * CFG["dims"]["s"]
                    AGENT.E = [0.0] * CFG["dims"]["E"]
                    AGENT.cycle = 0
                    AGENT.outputs.clear()
                    AGENT.prompt = ""
                    emit_event("CYCLE_RESET", to=0)
                else:
                    AGENT.prompt = str(data.get("prompt", "")).strip()[:512]
            elif path == "/api/pause":
                AGENT.paused = True
            elif path == "/api/reset":
                AGENT.cycle = 0
                emit_event("CYCLE_RESET", to=0)
        self.send_response(303)
        self.send_header("Location", "/")
        self.end_headers()


def loop():
    period = CFG["cycle_ms"] / 1000.0
    while AGENT.running:
        t = time.time()
        if not AGENT.paused:
            try:
                AGENT.step()
            except Exception as exc:
                AGENT.logs.appendleft(f"error: {exc}")
                emit_event("IO_FAULT", op="step", detail=str(exc))
        dt = time.time() - t
        if dt * 1000 > CFG["safety"]["watchdog_ms"]:
            emit_event("DT_GAP", dt_s=round(dt, 3))
        time.sleep(max(0.01, period - dt))


def main():
    def stop(*_):
        AGENT.running = False
        AGENT.persist()

    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    threading.Thread(target=loop, daemon=True).start()
    host, port = CFG.get("bind", "127.0.0.1"), int(CFG["port"])
    httpd = ThreadingHTTPServer((host, port), Handler)
    print(f"Φ-Lite v{VERSION} http://{host}:{port}/")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        stop()
        httpd.shutdown()


if __name__ == "__main__":
    main()
