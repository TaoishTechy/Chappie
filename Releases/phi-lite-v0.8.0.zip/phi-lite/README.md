# Φ-Lite v0.8.0

Memory crystal: 8-D boundary slots + nearest recall (JSON, not a quantum lattice).
I/O sub-settings in io_settings.json. HID/public bind fail-closed.
python3 phi_lite.py

