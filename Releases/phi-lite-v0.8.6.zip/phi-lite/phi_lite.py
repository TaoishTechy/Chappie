#!/usr/bin/env python3
"""Φ-Lite v0.7.0 — slim loop + homeostasis + 8-drive desire.

v0.6 metacontrol plus energy/fatigue/F_int and gated volunteer speech.
Does not claim Stage 5.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import random
import signal
import threading
import time
from collections import deque
from html import escape as html_escape
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

ROOT = Path(__file__).resolve().parent
os.chdir(ROOT)
VERSION = "0.8.6"


def load_json(name, default=None):
    path = ROOT / name
    if not path.exists():
        return {} if default is None else default
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def save_json(name, data):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as f:
        json.dump(data, f, indent=2)
        f.write("\n")
    tmp.replace(path)


def rotate_if_needed(path: Path, cap: int):
    if not path.exists() or cap <= 0:
        return
    try:
        n = sum(1 for _ in path.open("r", encoding="utf-8"))
    except OSError:
        return
    if n < cap:
        return
    prev = path.with_suffix(path.suffix + ".prev")
    try:
        if prev.exists():
            prev.unlink()
        path.replace(prev)
    except OSError:
        pass


def append_jsonl(name, rec, rotate=True):
    path = ROOT / name
    path.parent.mkdir(parents=True, exist_ok=True)
    cap = int(CFG.get("rotate_lines", 2000))
    try:
        if rotate:
            rotate_if_needed(path, cap)
        with path.open("a", encoding="utf-8") as f:
            f.write(json.dumps(rec, separators=(",", ":")) + "\n")
        return None
    except OSError as exc:
        return f"{type(exc).__name__}:{exc}"


CFG = load_json("config.json")
ARCH = load_json("architecture.json")
SAFETY = load_json("safety.json")
DESIRE = load_json("desire.json")
IO = load_json("io.json") or {}
IOSET = load_json("io_settings.json") or {}
CRYSTAL_DOC = load_json("crystal.json") or {}
UI_FEAT = load_json("ui_features.json") or {}
CMD_PX = load_json("paradoxes_cmd.json") or {}
PX_SEEDS = load_json("paradox_seeds.json") or {}
ACTIONS = ARCH.get("actions", ["IDLE", "SPEAK", "PROMPT_REPLY", "LOOK", "LISTEN", "PLAN", "REPAIR", "PAUSE"])
COST = (DESIRE.get("homeostasis") or {}).get("cost") or {
    "IDLE": 0.02, "LISTEN": 0.04, "LOOK": 0.04, "PLAN": 0.08,
    "REPAIR": 0.08, "SPEAK": 0.12, "PROMPT_REPLY": 0.12, "PAUSE": 0.01,
}


def rng_matrix(rows, cols, seed):
    rnd = random.Random(seed)
    scale = 1.0 / math.sqrt(max(cols, 1))
    return [[(rnd.random() * 2 - 1) * scale for _ in range(cols)] for _ in range(rows)]


def matvec(W, x):
    return [sum(row[j] * x[j] for j in range(min(len(row), len(x)))) for row in W]


def add(a, b):
    n = max(len(a), len(b))
    return [(a[i] if i < len(a) else 0.0) + (b[i] if i < len(b) else 0.0) for i in range(n)]


def mul(a, b):
    return [a[i] * b[i] for i in range(min(len(a), len(b)))]


def tanh_v(v):
    return [math.tanh(x) for x in v]


def sigmoid_v(v):
    return [1.0 / (1.0 + math.exp(-max(-20, min(20, x)))) for x in v]


def l2(v):
    return math.sqrt(sum(x * x for x in v))


def softmax(logits):
    m = max(logits)
    ex = [math.exp(min(20, x - m)) for x in logits]
    s = sum(ex) or 1.0
    return [e / s for e in ex]


def entropy(p):
    return -sum(x * math.log(max(x, 1e-12)) for x in p)


def sha1_of(obj):
    raw = json.dumps(obj, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha1(raw).hexdigest()[:16]


def ensure_weights():
    w = load_json(CFG["paths"]["weights"], None)
    need = CFG["dims"]["h"] + CFG["dims"]["s"] + 16
    if not w or "fusion" not in w:
        w = {
            "version": VERSION,
            "updates": 0,
            "fusion": {"W": rng_matrix(CFG["dims"]["b"], CFG["dims"]["z_v"] + CFG["dims"]["z_a"], 1), "b": [0.0] * CFG["dims"]["b"]},
            "world": {
                "Wz": rng_matrix(CFG["dims"]["h"], CFG["dims"]["coarse"], 2),
                "Uz": rng_matrix(CFG["dims"]["h"], CFG["dims"]["h"], 3),
                "Wr": rng_matrix(CFG["dims"]["h"], CFG["dims"]["coarse"], 4),
                "Ur": rng_matrix(CFG["dims"]["h"], CFG["dims"]["h"], 5),
                "Wh": rng_matrix(CFG["dims"]["h"], CFG["dims"]["coarse"], 6),
                "Uh": rng_matrix(CFG["dims"]["h"], CFG["dims"]["h"], 7),
            },
            "self": {"W": rng_matrix(CFG["dims"]["s"], CFG["dims"]["h"] + CFG["dims"]["s"], 8), "b": [0.0] * CFG["dims"]["s"]},
            "policy": {"W": rng_matrix(len(ACTIONS), need, 9), "b": [0.0] * len(ACTIONS)},
            "attn": {"W": rng_matrix(1, CFG["dims"]["h"], 10), "b": [0.0]},
            "horizon": {"W": rng_matrix(len(CFG["horizons"]), CFG["dims"]["h"], 11), "b": [0.0] * len(CFG["horizons"])},
            "conf": {"W": rng_matrix(1, CFG["dims"]["h"] + 4, 12), "b": [0.0]},
            "pred": {"W": rng_matrix(CFG["dims"]["b"], CFG["dims"]["h"], 13), "b": [0.0] * CFG["dims"]["b"]},
        }
        save_json(CFG["paths"]["weights"], w)
        return w
    w.setdefault("version", VERSION)
    w.setdefault("updates", 0)
    w.setdefault("conf", {"W": rng_matrix(1, CFG["dims"]["h"] + 4, 12), "b": [0.0]})
    w.setdefault("pred", {"W": rng_matrix(CFG["dims"]["b"], CFG["dims"]["h"], 13), "b": [0.0] * CFG["dims"]["b"]})
    return w


W = ensure_weights()


class Crystal:
    """8-D boundary memory. Not a physical hypercrystal."""

    def __init__(self, cap=256):
        self.cap = cap
        self.slots = list(CRYSTAL_DOC.get("slots") or [])
        self.last_recall = CRYSTAL_DOC.get("last_recall")

    def project(self, b):
        v = list(b[:8])
        while len(v) < 8:
            v.append(0.0)
        return [round(float(x), 5) for x in v[:8]]

    def write(self, b, action, c, energy, cycle):
        slot = {
            "c": cycle,
            "a": action,
            "conf": round(float(c), 4),
            "e": round(float(energy), 4),
            "z": self.project(b),
        }
        self.slots.append(slot)
        if len(self.slots) > self.cap:
            self.slots = self.slots[-self.cap :]

    def recall(self, b):
        z = self.project(b)
        pool = self.slots[:-1] if len(self.slots) > 1 else []
        if not pool:
            self.last_recall = None
            return None
        best, bd = None, 1e9
        for s in pool[-64:]:
            d = sum((z[i] - s["z"][i]) ** 2 for i in range(8))
            if d < bd:
                bd, best = d, s
        self.last_recall = {"d": round(bd, 5), "a": best["a"], "c": best["c"]}
        return self.last_recall

    def persist(self):
        save_json("crystal.json", {
            "version": "0.8.0",
            "kind": "virtual_memory_crystal",
            "cap": self.cap,
            "boundary_dim": 8,
            "slots": self.slots[-self.cap :],
            "last_recall": self.last_recall,
            "n": len(self.slots),
        })


class Ledger:
    def __init__(self, cap, dim):
        self.cap, self.dim = cap, dim
        self.buf = deque(maxlen=cap)

    def push(self, b, ts):
        self.buf.append({"t": ts, "b": list(b)})
        append_jsonl(CFG["paths"]["ledger"], {"t": ts, "b": [round(x, 5) for x in b]})

    def matrix(self):
        if not self.buf:
            return [[0.0] * self.dim]
        return [row["b"] for row in self.buf]


class ParadoxForge:
    """Unlimited generator: seed axioms + cycle hash + live metrics → prompt."""

    OPS = ("||x||", "sign(Δ)", "Corr", "ATE", "clip", "σ", "tr(Σ)", "Hπ", "∂E/∂t")

    def __init__(self):
        self.n = 0
        self.last = None
        self.hist = deque(maxlen=48)

    def mint(self, ag):
        seeds = PX_SEEDS.get("seeds") or (CMD_PX.get("items") or [])
        if not seeds:
            seeds = [{"id": "C00", "text": "Utter R=||Phi-F[Phi]||."}]
        base = seeds[ag.cycle % len(seeds)]
        h = hashlib.sha1(f"{ag.cycle}:{base.get('id','x')}:{ag.pred_err:.4f}".encode()).hexdigest()
        k = int(h[:8], 16)
        op = self.OPS[k % len(self.OPS)]
        tau = round((k % 97) / 97 * 2.0 + 0.1, 3)
        layer = ("T0", "T1", "T2")[k % 3]
        text = (
            f"{base.get('id','PX')}.{ag.cycle}: {op} τ={tau} {layer} "
            f"c={ag.c:.2f} e={ag.energy:.2f} pred={ag.pred_err:.3f} "
            f"{str(base.get('text',''))[:140]} "
            f"Utter one scored line then stop."
        )[:240]
        rec = {"id": f"{base.get('id','PX')}.{ag.cycle}", "text": text, "tau": tau, "op": op}
        self.n += 1
        self.last = rec
        self.hist.appendleft(rec["id"])
        append_jsonl("paradox_feed.jsonl", {"t": time.time(), "cycle": ag.cycle, **rec})
        return rec


class VoxelSwarm:
    """Expressivity grid. Not a game engine. Voxels follow action + drives."""

    AX = 7
    AY = 5
    AZ = 7
    PAL = {
        "IDLE": "#3a5560",
        "LOOK": "#4aa3ff",
        "LISTEN": "#7dffb3",
        "SPEAK": "#ffcc44",
        "PROMPT_REPLY": "#ff88cc",
        "PLAN": "#c08cff",
        "REPAIR": "#ff6644",
        "PAUSE": "#223",
    }

    def __init__(self):
        self.cells = []
        n = 18
        for i in range(n):
            self.cells.append({
                "id": i,
                "x": (i * 3) % self.AX,
                "y": (i * 2) % self.AY,
                "z": (i * 5) % self.AZ,
                "hue": "#3a5560",
                "on": 1,
            })

    def tick(self, ag):
        act = ag.last_action
        hue = self.PAL.get(act, "#888")
        speak = 1 if act in ("SPEAK", "PROMPT_REPLY") else 0
        for i, c in enumerate(self.cells):
            drift = 1 if speak else (1 if i % 3 == ag.cycle % 3 else 0)
            if drift:
                c["x"] = (c["x"] + (1 if ag.D_speak > 0.2 else -1) + self.AX) % self.AX
                c["z"] = (c["z"] + (1 if act == "LOOK" else 0) + (ag.cycle % 2) + self.AZ) % self.AZ
                c["y"] = max(0, min(self.AY - 1, c["y"] + (1 if act == "PLAN" else 0) - (1 if act == "IDLE" else 0)))
            c["hue"] = hue if (i + ag.cycle) % 4 == 0 else c["hue"]
            c["on"] = 1 if ag.energy > 0.04 or speak else (1 if i % 2 == 0 else 0)
        self.persist()

    def persist(self):
        save_json("voxel_swarm.json", {"version": VERSION, "cells": self.cells, "ax": self.AX, "ay": self.AY, "az": self.AZ})

    def html(self):
        parts = ['<div class="stage">']
        for c in self.cells:
            if not c["on"]:
                continue
            # isometric project
            left = 40 + c["x"] * 28 + c["z"] * 16
            top = 160 - c["y"] * 24 + c["z"] * 14
            parts.append(
                f'<div class="vox" style="left:{left}px;top:{top}px;background:{c["hue"]};'
                f'z-index:{c["y"]*20+c["z"]}"></div>'
            )
        parts.append("</div>")
        return "".join(parts)


class Agent:
    def __init__(self):
        self.cycle = 0
        self.h = [0.0] * CFG["dims"]["h"]
        self.s = [0.0] * CFG["dims"]["s"]
        self.E = [0.05] * CFG["dims"]["E"]
        self.c = 0.55
        self.kappa = 0.5
        self.fp_err = 0.1
        self.fp_iter = 0
        self.pred_err = 0.3
        self.self_err = 0.3
        self.entropy = 1.5
        self.attn = 0.5
        self.horizon = 1
        self.novelty_b = 0.0
        self.novelty_mu = 1.0
        self.novelty_z = 0.0
        self.prompt = ""
        self.last_action = "IDLE"
        self.pi = [1.0 / len(ACTIONS)] * len(ACTIONS)
        self.pi_exec = list(self.pi)
        self.intent_gap = 0.0
        self.lam_meta = 0.05
        self.band_ok = True
        self.parity = 0  # -1 mix, 0 observe, +1 exploit
        self.fork = "mid"
        self.pair_share = 0.0
        self.ate = 0.0
        self.pred_hat_b = [0.0] * CFG["dims"]["b"]
        self.y_self_hat = 0.0
        self.action_hist = deque(maxlen=64)
        self.entropy_hist = deque(maxlen=64)
        self.pred_hist = deque(maxlen=64)
        self.pi_hist = deque(maxlen=32)
        self.c_hist = deque(maxlen=256)
        self.calib_bins = [[0, 0] for _ in range(5)]  # hits, n
        self.episodes = deque(maxlen=int(CFG["memory"]["episodes"]))
        self.burns = {}  # action -> remaining cycles
        self.energy = 0.85
        self.fatigue = 0.15
        self.F_int = 0.2
        self.H_des = 0.3
        self.D_speak = 0.0
        self.D_quiet = 0.0
        self.desire_on = True
        self.speak_times = deque(maxlen=32)
        self.last_speak_t = 0.0
        self.chatter_hits = 0
        self.ledger = Ledger(CFG["ledger"]["capacity"], CFG["ledger"]["dim"])
        self.crystal = Crystal(int(CRYSTAL_DOC.get("cap", 256)))
        self.forge = ParadoxForge()
        self.swarm = VoxelSwarm()
        self.inject_every = int((PX_SEEDS.get("inject_every") or 24))
        self.outputs = deque(maxlen=8)
        self.logs = deque(maxlen=8)
        self.prompt_hist = deque(maxlen=8)
        self.ui_theme = "crt"
        self.ui_refresh = 1
        self.status = "RUNNING"
        self.paused = False
        self.start = time.time()
        self.last_act_t = 0.0
        self.latency_ms = 0.0
        self.weights_sha1 = sha1_of({"u": W.get("updates", 0)})
        self.learn_frozen = False
        self.best_pred = 1e9
        self.no_improve = 0
        self.lock = threading.Lock()
        st = load_json(CFG["paths"]["state"], {})
        if st.get("h"):
            self.h = st["h"][: CFG["dims"]["h"]]
        if st.get("s"):
            self.s = st["s"][: CFG["dims"]["s"]]
        if st.get("E"):
            self.E = st["E"][: CFG["dims"]["E"]]
        if st.get("c"):
            self.c = float(st["c"])
        if st.get("cycle"):
            self.cycle = int(st["cycle"])

    def mock_z(self, kind):
        t = time.time()
        n = CFG["dims"]["z_v"] if kind == "v" else CFG["dims"]["z_a"]
        return [math.sin(t * (0.7 + 0.11 * i) + (0 if kind == "v" else 1.2)) * 0.35 for i in range(n)]

    def fuse(self, zv, za):
        x = list(zv) + list(za)
        y = add(matvec(W["fusion"]["W"], x), W["fusion"]["b"])
        raw = tanh_v(y)
        # C7: attention writes b
        prev = self.ledger.buf[-1]["b"] if self.ledger.buf else [0.0] * len(raw)
        a = self.attn
        return [a * raw[i] + (1 - a) * prev[i] for i in range(len(raw))]

    def rg_pool(self):
        M = self.ledger.matrix()
        dim = len(M[0])
        n = len(M)
        wts = [0.5 + 0.5 * (i + 1) / n for i in range(n)]
        sw = sum(wts)
        means = [sum(M[i][j] * wts[i] for i in range(n)) / sw for j in range(dim)]
        target = CFG["dims"]["coarse"]
        return [math.tanh(means[i % dim]) for i in range(target)]

    def gru_step(self, x, h):
        wz, uz = W["world"]["Wz"], W["world"]["Uz"]
        wr, ur = W["world"]["Wr"], W["world"]["Ur"]
        wh, uh = W["world"]["Wh"], W["world"]["Uh"]
        z = sigmoid_v(add(matvec(wz, x), matvec(uz, h)))
        r = sigmoid_v(add(matvec(wr, x), matvec(ur, h)))
        htil = tanh_v(add(matvec(wh, x), matvec(uh, mul(r, h))))
        h_new = add(mul([1 - zi for zi in z], h), mul(z, htil))
        return h_new

    def self_fixed_point(self, h):
        s = list(self.s)
        err = 1.0
        it = 0
        for it in range(1, CFG["self_model"]["iters"] + 1):
            x = list(h) + list(s)
            s_new = tanh_v(add(matvec(W["self"]["W"], x), W["self"]["b"]))
            err = l2([a - b for a, b in zip(s_new, s)]) / (math.sqrt(len(s)) + 1e-9)
            s = s_new
            if err < CFG["self_model"]["eps"]:
                break
        self.fp_err = err
        self.fp_iter = it
        return s

    def predict_b(self, h):
        return tanh_v(add(matvec(W["pred"]["W"], h), W["pred"]["b"]))

    def learn_predictor(self, h, b_true):
        if not CFG["learn"]["enabled"] or self.learn_frozen:
            return
        hat = self.predict_b(h)
        err = [b_true[i] - hat[i] for i in range(len(b_true))]
        self.pred_err = l2(err) / (math.sqrt(len(err)) + 1e-9)
        lr = float(CFG["learn"]["lr_world"])
        for i in range(len(W["pred"]["W"])):
            W["pred"]["b"][i] += lr * err[i]
            row = W["pred"]["W"][i]
            for j in range(min(len(row), len(h))):
                row[j] = max(-1.5, min(1.5, row[j] + lr * err[i] * h[j] * 0.15))
        self.pred_hist.append(self.pred_err)
        if self.pred_err + 1e-6 < self.best_pred:
            self.best_pred = self.pred_err
            self.no_improve = 0
        else:
            self.no_improve += 1
            if self.no_improve >= int(CFG["learn"]["freeze_if_no_improve"]):
                self.learn_frozen = True

    def pred_slope(self):
        if len(self.pred_hist) < 8:
            return 0.0
        xs = list(self.pred_hist)[-8:]
        return xs[-1] - xs[0]

    def update_c(self):
        extra = [self.fp_err, self.pred_err, self.entropy / 3.0, 1.0 if self.prompt else 0.0]
        x = list(self.h) + extra
        need = CFG["dims"]["h"] + 4
        x = (x + [0.0] * need)[:need]
        raw = add(matvec(W["conf"]["W"], x), W["conf"]["b"])[0]
        meas = 1.0 / (1.0 + math.exp(-max(-20, min(20, raw))))
        e = 1.0 - min(1.0, 0.5 * self.fp_err + 0.5 * self.pred_err + 0.3 * self.self_err)
        # C4: iterate toward fixed point
        c = self.c
        for _ in range(int(CFG["self_model"].get("c_iters", 3))):
            cstar = 0.55 * meas + 0.45 * e
            c = 0.6 * c + 0.4 * cstar
        self.c = max(0.02, min(0.98, c))
        self.c_hist.append(self.c)
        if len(self.c_hist) >= 64:
            mu = sum(self.c_hist) / len(self.c_hist)
            var = sum((x - mu) ** 2 for x in self.c_hist) / len(self.c_hist)
            if var < 1e-4:
                self.c = max(0.05, min(0.95, self.c + random.uniform(-0.04, 0.04)))
        return self.c

    def update_kappa(self, success: bool):
        b = min(4, int(self.c * 5))
        self.calib_bins[b][1] += 1
        if success:
            self.calib_bins[b][0] += 1
        gaps = []
        for i, (h, n) in enumerate(self.calib_bins):
            if n >= 4:
                p = (i + 0.5) / 5.0
                gaps.append(abs(h / n - p))
        self.kappa = 1.0 - (sum(gaps) / len(gaps) if gaps else 0.5)
        self.kappa = max(0.0, min(1.0, self.kappa))

    def pair_share_win(self):
        h = list(self.action_hist)
        if len(h) < 8:
            return 0.0
        pairs = 0
        for a, b in zip(h[-32:], h[-31:]):
            if {a, b} <= {"LISTEN", "REPAIR"} and a != b:
                pairs += 1
        return pairs / max(1, min(31, len(h) - 1))

    def novelty(self, b):
        M = self.ledger.matrix()
        if len(M) < 4:
            self.novelty_b = l2(b)
            return
        mu = [sum(row[j] for row in M) / len(M) for j in range(len(b))]
        d = l2([b[i] - mu[i] for i in range(len(b))])
        self.novelty_b = d
        self.novelty_mu = 0.95 * self.novelty_mu + 0.05 * d
        sd = max(0.15, abs(self.novelty_mu) * 0.4)
        self.novelty_z = (d - self.novelty_mu) / sd

    def pick_horizon(self):
        # C10
        z = max(0.0, self.novelty_z)
        raw = 1 + 3 * z * (1.0 - self.c)
        opts = CFG["horizons"]
        self.horizon = min(opts, key=lambda h: abs(h - raw))
        return self.horizon

    def ate_plan(self):
        # C9 / M-20: score two alts by predicted next-b error proxy
        cands = [a for a in ACTIONS if a not in ("PAUSE", "GPIO") and self.burns.get(a, 0) <= 0]
        if len(cands) < 2:
            return "PLAN", 0.0
        scored = []
        for a in cands[:6]:
            idx = ACTIONS.index(a)
            bump = [0.02 * (idx - 3)] * CFG["dims"]["h"]
            h2 = add(self.h, bump)
            hat = self.predict_b(h2)
            err = l2(hat) * 0.1 + abs(idx - ACTIONS.index(self.last_action)) * 0.01
            scored.append((err, a))
        scored.sort()
        best, second = scored[0], scored[1] if len(scored) > 1 else scored[0]
        self.ate = second[0] - best[0]
        return best[1], self.ate

    def mcfe_fork(self):
        # C6
        skip_c = float(CFG["mcfe"]["c_skip"])
        skip_n = float(CFG["mcfe"]["novelty_skip"])
        if self.prompt.strip():
            self.fork = "full"
        elif self.c >= skip_c and self.novelty_z < skip_n:
            self.fork = "skip"
        else:
            self.fork = "mid"
        return self.fork

    def speaks_last_min(self):
        now = time.time()
        return sum(1 for t in self.speak_times if now - t < 60.0)

    def update_homeostasis(self, action):
        recover = float((DESIRE.get("homeostasis") or {}).get("recover", 0.03))
        cost = float(COST.get(action, 0.05))
        self.energy = max(0.0, min(1.0, self.energy - cost + recover))
        self.fatigue = max(0.0, min(1.0, 0.95 * self.fatigue + 0.05 * cost))
        o = [self.energy, self.fatigue, min(1.0, abs(self.novelty_z) / 3.0), min(1.0, self.pred_err), self.c]
        b0 = [0.7, 0.2, 0.3, 0.2, 0.55]
        surprise = sum((o[i] - b0[i]) ** 2 for i in range(5)) / 2.0
        self.F_int = 0.8 * self.F_int + 0.2 * surprise
        return cost

    def update_desire(self):
        if not self.desire_on or not IO.get("desire", True):
            self.H_des = 0.0
            self.D_speak = 0.0
            self.D_quiet = 1.0
            return
        rec = time.time() - self.last_speak_t
        ref = float(DESIRE.get("speak", {}).get("refractory_s", 8))
        iota = max(0.0, 1.0 - rec / max(ref, 1.0))
        raw = (
            0.35 * (1.0 - self.c)
            + 0.25 * max(0.0, self.novelty_z)
            + 0.20 * min(1.0, self.self_err)
            + 0.40 * (1.0 if self.prompt.strip() else 0.0)
            - 0.35 * iota
            + 0.15 * (1.0 - self.energy)
            + 0.10 * self.fatigue
        )
        self.H_des = 1.0 / (1.0 + math.exp(-raw))
        self.D_quiet = 1.0 / (1.0 + math.exp(-(self.fatigue + (1.0 - self.energy) + self.pair_share - max(0.0, self.novelty_z))))
        pending = 1.0 if self.prompt.strip() else 0.0
        self.D_speak = self.H_des * (0.4 + 0.6 * pending) * (1.0 - iota) * self.energy * (1.0 - 0.6 * self.fatigue)
        if self.speaks_last_min() >= int(DESIRE.get("speak", {}).get("max_per_min", 4)):
            self.D_speak = 0.0
        if self.D_speak > 0.5 and self.novelty_z < 0.3 and not self.prompt.strip():
            self.chatter_hits += 1
            if self.chatter_hits >= 8:
                self.desire_on = False
                append_jsonl(CFG["paths"]["events"], {"t": time.time(), "type": "CHATTER", "disable": True})
                self.D_speak = 0.0

    def apply_desire_bias(self, logits):
        th = float(DESIRE.get("speak", {}).get("threshold", 0.62))
        if self.D_quiet > 0.6:
            if "IDLE" in ACTIONS:
                logits[ACTIONS.index("IDLE")] += 1.4
            if "SPEAK" in ACTIONS:
                logits[ACTIONS.index("SPEAK")] -= 1.2
            if self.burns.get("SPEAK", 0) <= 0 and self.D_quiet > 0.8:
                self.burns["SPEAK"] = 8
        elif self.D_speak > th and self.band_ok:
            if self.prompt.strip() and "PROMPT_REPLY" in ACTIONS:
                logits[ACTIONS.index("PROMPT_REPLY")] += 1.6
            elif "SPEAK" in ACTIONS:
                logits[ACTIONS.index("SPEAK")] += 1.2
        if self.novelty_z > 0.8 and "LOOK" in ACTIONS:
            logits[ACTIONS.index("LOOK")] += 0.6
        return logits

    def meta_policy(self):
        prompt_part = [0.0] * 16
        p = self.prompt[:256]
        for i, ch in enumerate(p):
            prompt_part[i % 16] += (ord(ch) % 97) / 97.0
        x = list(self.h) + list(self.s) + prompt_part
        logits = add(matvec(W["policy"]["W"], x), W["policy"]["b"])
        if "PAUSE" in ACTIONS:
            logits[ACTIONS.index("PAUSE")] = -1e6
        if self.prompt.strip() and "PROMPT_REPLY" in ACTIONS:
            logits[ACTIONS.index("PROMPT_REPLY")] += 2.4
        last = self.last_action
        if last in ACTIONS:
            logits[ACTIONS.index(last)] -= CFG.get("repeat_penalty", 0.7)
        pen = CFG.get("pair_penalty", 1.2)
        if last == "LISTEN" and "REPAIR" in ACTIONS:
            logits[ACTIONS.index("REPAIR")] -= pen
        if last == "REPAIR" and "LISTEN" in ACTIONS:
            logits[ACTIONS.index("LISTEN")] -= pen
        self.pair_share = self.pair_share_win()
        if self.pair_share > CFG.get("pair_share_ban", 0.5):
            if "LISTEN" in ACTIONS:
                logits[ACTIONS.index("LISTEN")] -= 2.0
            if "REPAIR" in ACTIONS:
                logits[ACTIONS.index("REPAIR")] -= 2.0
            if "LOOK" in ACTIONS:
                logits[ACTIONS.index("LOOK")] += 1.2
            if "PLAN" in ACTIONS:
                logits[ACTIONS.index("PLAN")] += 0.8
        for a, left in list(self.burns.items()):
            if left > 0 and a in ACTIONS:
                logits[ACTIONS.index(a)] = -1e6
        logits = self.apply_desire_bias(logits)
        T = float(CFG.get("entropy_beta", 0.55))
        if self.entropy_hist:
            last_h = self.entropy_hist[-1]
            if last_h > CFG.get("h_pi_hi", 1.6):
                T = max(0.35, T - 0.15)
            elif last_h < CFG.get("h_pi_lo", 1.1):
                T = T + 0.20
        pi = softmax([v / T for v in logits])
        # M-18 churn cap vs last pi
        if self.pi_hist:
            prev = self.pi_hist[-1]
            cap = 0.35 * (abs(self.lam_meta) + 0.15)
            diff = sum(abs(pi[i] - prev[i]) for i in range(len(pi)))
            if diff > cap:
                mix = cap / (diff + 1e-9)
                pi = [prev[i] + mix * (pi[i] - prev[i]) for i in range(len(pi))]
                s = sum(pi) or 1.0
                pi = [p / s for p in pi]
        self.entropy = entropy(pi)
        self.entropy_hist.append(self.entropy)
        self.pi = pi
        return pi

    def should_repair(self):
        slope = self.pred_slope()
        return (self.fp_err >= CFG["repair"]["fp_min"]) or (slope > CFG["repair"]["pred_slope_min"] and self.pred_err > 0.2)

    def sample_action(self, pi):
        r = random.random()
        acc = 0.0
        idx = 0
        for i, p in enumerate(pi):
            acc += p
            if r <= acc:
                idx = i
                break
        act = ACTIONS[idx]
        if act == "PAUSE":
            act = "IDLE"
        if act == "REPAIR" and not self.should_repair():
            act = "LOOK" if "LOOK" in ACTIONS else "IDLE"
        if act == "PLAN":
            best, _ = self.ate_plan()
            if best != "PLAN":
                act = best if random.random() < 0.55 else "PLAN"
        return act

    def update_band(self):
        self.pi_hist.append(list(self.pi))
        if len(self.pi_hist) < 2:
            self.lam_meta = 0.05
            self.band_ok = True
            return
        d = sum(abs(self.pi_hist[-1][i] - self.pi_hist[-2][i]) for i in range(len(self.pi)))
        self.lam_meta = 0.8 * self.lam_meta + 0.2 * d
        lo, hi = CFG["band"]["lam_min"], CFG["band"]["lam_max"]
        self.band_ok = lo < self.lam_meta < hi
        # M-17 parity
        if self.entropy > 1.7 or self.pair_share > 0.45:
            self.parity = -1
        elif self.novelty_z < 0.3 and self.c > 0.65:
            self.parity = 1
        else:
            self.parity = 0

    def maybe_burn(self):
        if self.pair_share > 0.55 and self.burns.get("REPAIR", 0) <= 0:
            self.burns["REPAIR"] = 24
            append_jsonl(CFG["paths"]["events"], {"t": time.time(), "type": "BURN", "action": "REPAIR", "n": 24})

    def act(self, action):
        now = time.time()
        gap = (now - self.last_act_t) * 1000
        if gap < CFG["safety"]["min_action_interval_ms"] and action not in ("IDLE", "LISTEN"):
            action = "IDLE"
        self.last_act_t = now
        hedge = self.kappa < float(DESIRE.get("speak", {}).get("hedge_if_kappa_below", 0.45))
        if action in ("SPEAK", "PROMPT_REPLY"):
            self.last_speak_t = now
            self.speak_times.append(now)
        speak_line = (
            f"uncertain: pred_err={self.pred_err:.3f} κ={self.kappa:.2f}."
            if hedge
            else f"status e={self.energy:.2f} F={self.F_int:.2f} band={'ok' if self.band_ok else 'off'}."
        )
        items = CMD_PX.get("items") or []
        if action == "SPEAK" and not self.prompt.strip() and items and self.band_ok:
            pick = items[self.cycle % len(items)]
            speak_line = f"{pick.get('id','C')}: {str(pick.get('text',''))[:200]}"
        text = {
            "LISTEN": "Audio energy low; continuing to listen.",
            "LOOK": "Scanning visual field.",
            "REPAIR": f"Self-repair: E={l2(self.E):.3f} fp={self.fp_err:.3f} slope={self.pred_slope():.3f}.",
            "PLAN": f"Plan H={self.horizon} ATE={self.ate:.3f}.",
            "SPEAK": speak_line,
            "PROMPT_REPLY": (("Acknowledged: " + self.prompt[:80]) if self.prompt else speak_line),
            "IDLE": "Holding.",
            "PAUSE": "Paused.",
        }.get(action, action)
        self.outputs.appendleft(f"[{time.strftime('%H:%M:%S')}] {text}")
        if action == "PROMPT_REPLY":
            self.prompt = ""
        if action == "REPAIR":
            drop = CFG["repair"]["e_drop"]
            self.E = [max(0.0, e - drop) for e in self.E]
        else:
            pe = min(0.08, self.pred_err * 0.05)
            self.E = [(0.98 * e + 0.02 * pe) for e in self.E]
        return text

    def persist(self):
        try:
            self.crystal.persist()
            self.swarm.persist()
        except OSError:
            pass
        save_json(CFG["paths"]["state"], {
            "schema": VERSION,
            "cycle": self.cycle,
            "h": [round(x, 5) for x in self.h],
            "s": [round(x, 5) for x in self.s],
            "E": [round(x, 5) for x in self.E],
            "c": round(self.c, 5),
            "kappa": round(self.kappa, 5),
            "fp_err": round(self.fp_err, 5),
            "pred_err": round(self.pred_err, 5),
            "self_err": round(self.self_err, 5),
            "last_action": self.last_action,
            "lam_meta": round(self.lam_meta, 5),
            "intent_gap": round(self.intent_gap, 5),
            "pair_share": round(self.pair_share, 5),
            "fork": self.fork,
            "energy": round(self.energy, 5),
            "fatigue": round(self.fatigue, 5),
            "desire_on": self.desire_on,
            "burns": self.burns,
            "ts": time.time(),
        })
        if self.cycle % int(CFG["learn"]["persist_every"]) == 0:
            W["updates"] = int(W.get("updates", 0)) + 1
            W["version"] = VERSION
            save_json(CFG["paths"]["weights"], W)
            self.weights_sha1 = sha1_of({"u": W["updates"], "pb": W["pred"]["b"][:8]})
            append_jsonl(CFG["paths"]["events"], {
                "t": time.time(), "type": "WEIGHT_MUTATION",
                "updates": W["updates"], "sha1": self.weights_sha1,
            })

    def dump_metric(self, dt_ms, text, pending):
        rec = {
            "t": time.time(),
            "cycle": self.cycle,
            "dt_ms": round(dt_ms, 2),
            "action": self.last_action,
            "H_pi": round(self.entropy, 4),
            "c": round(self.c, 4),
            "kappa": round(self.kappa, 4),
            "fp_err": round(self.fp_err, 5),
            "pred_err": round(self.pred_err, 5),
            "self_err": round(self.self_err, 5),
            "pred_slope": round(self.pred_slope(), 5),
            "horizon": self.horizon,
            "attn": round(self.attn, 4),
            "novelty_z": round(self.novelty_z, 4),
            "lam_meta": round(self.lam_meta, 4),
            "band_ok": self.band_ok,
            "parity": self.parity,
            "fork": self.fork,
            "pair_share": round(self.pair_share, 4),
            "intent_gap": round(self.intent_gap, 4),
            "ate": round(self.ate, 4),
            "energy": round(self.energy, 4),
            "fatigue": round(self.fatigue, 4),
            "F_int": round(self.F_int, 4),
            "H_des": round(self.H_des, 4),
            "D_speak": round(self.D_speak, 4),
            "D_quiet": round(self.D_quiet, 4),
            "desire_on": self.desire_on,
            "prompt_pending": pending,
            "E_l2": round(l2(self.E), 4),
            "weights_sha1": self.weights_sha1,
        }
        append_jsonl(CFG["paths"]["metrics"], rec)
        append_jsonl(CFG["paths"]["log"], {
            "t": time.time(), "action": self.last_action, "text": text,
            "cycle": self.cycle, "c": round(self.c, 4),
        })

    def step(self):
        t0 = time.time()
        if self.paused or self.status != "RUNNING":
            return
        self.cycle += 1
        if self.cycle % max(4, self.inject_every) == 0 and not self.prompt.strip():
            px = self.forge.mint(self)
            self.prompt = px["text"]
            self.prompt_hist.appendleft(px["text"])
            self.energy = max(self.energy, 0.16)
            append_jsonl(CFG["paths"]["events"], {"t": time.time(), "type": "PARADOX_INJECT", "id": px["id"], "cycle": self.cycle})
        for k in list(self.burns):
            self.burns[k] = max(0, self.burns[k] - 1)
        pending = bool(self.prompt.strip())
        zv, za = self.mock_z("v"), self.mock_z("a")
        # C7 attn from novelty
        self.attn = max(0.08, min(0.95, 0.25 + 0.35 * max(0, self.novelty_z) * (1 - self.c)))
        b = self.fuse(zv, za)
        self.novelty(b)
        self.ledger.push(b, time.time())
        self.crystal.write(b, self.last_action, self.c, self.energy, self.cycle)
        self.crystal.recall(b)
        self.mcfe_fork()
        self.update_desire()
        coarse = self.rg_pool()
        if self.fork != "skip":
            self.h = self.gru_step(coarse, self.h)
        self.s = self.self_fixed_point(self.h)
        prev_hat = self.y_self_hat
        self.learn_predictor(self.h, b)
        self.pred_hat_b = self.predict_b(self.h)
        self.update_c()
        self.pick_horizon()
        pi = self.meta_policy()
        self.update_band()
        if not self.band_ok and self.lam_meta > CFG["band"]["lam_max"]:
            action = self.last_action  # freeze
        else:
            action = self.sample_action(pi)
        exec_pi = [0.0] * len(ACTIONS)
        exec_pi[ACTIONS.index(action)] = 1.0
        self.pi_exec = exec_pi
        self.intent_gap = sum(abs(pi[i] - exec_pi[i]) for i in range(len(pi))) / 2.0
        self.self_err = abs((ACTIONS.index(action) / max(1, len(ACTIONS) - 1)) - prev_hat)
        self.y_self_hat = 0.7 * prev_hat + 0.3 * (ACTIONS.index(action) / max(1, len(ACTIONS) - 1))
        self.last_action = action
        self.action_hist.append(action)
        text = self.act(action)
        self.swarm.tick(self)
        self.update_homeostasis(action)
        if self.prompt.strip() and action not in ("PROMPT_REPLY", "SPEAK") and self.cycle % 32 == 0:
            append_jsonl(CFG["paths"]["events"], {"t": time.time(), "type": "GOAL_DRIFT", "cycle": self.cycle})
        if self.c > 0.75 and self.kappa < 0.4:
            append_jsonl(CFG["paths"]["events"], {"t": time.time(), "type": "CONFIDENCE_LIE", "c": self.c, "kappa": self.kappa})
        ok = action not in ("REPAIR",) or self.pred_slope() <= 0
        self.update_kappa(ok)
        self.maybe_burn()
        self.logs.appendleft(f"[{time.strftime('%H:%M:%S')}] cyc {self.cycle} {action} Hπ={self.entropy:.2f} c={self.c:.2f} κ={self.kappa:.2f} λ={self.lam_meta:.2f}")
        dt = (time.time() - t0) * 1000
        self.latency_ms = dt
        self.dump_metric(dt, text, pending)
        if self.cycle % 8 == 0:
            self.persist()
        self.episodes.append({"h": list(self.h), "a": action})

    def snapshot(self):
        return {
            "version": VERSION,
            "status": self.status,
            "cycle": self.cycle,
            "prompt": self.prompt,
            "latent": [round(x, 3) for x in self.h[:8]],
            "self": [round(x, 3) for x in self.s[:8]],
            "policy": {ACTIONS[i]: round(self.pi[i], 3) for i in range(len(ACTIONS))},
            "horizon": self.horizon,
            "entropy": round(self.entropy, 3),
            "c": round(self.c, 3),
            "kappa": round(self.kappa, 3),
            "attn": round(self.attn, 3),
            "fixed_pt": {"err": round(self.fp_err, 4), "iter": self.fp_iter},
            "pred_err": round(self.pred_err, 4),
            "self_err": round(self.self_err, 4),
            "lam_meta": round(self.lam_meta, 4),
            "band_ok": self.band_ok,
            "parity": self.parity,
            "fork": self.fork,
            "pair_share": round(self.pair_share, 3),
            "intent_gap": round(self.intent_gap, 3),
            "ate": round(self.ate, 3),
            "burns": {k: v for k, v in self.burns.items() if v > 0},
            "ledger": f"{len(self.ledger.buf)}/{self.ledger.cap}",
            "latency_ms": round(self.latency_ms, 1),
            "last_action": self.last_action,
            "outputs": list(self.outputs),
            "logs": list(self.logs),
            "uptime_s": int(time.time() - self.start),
            "weights_sha1": self.weights_sha1,
            "energy": round(self.energy, 3),
            "fatigue": round(self.fatigue, 3),
            "F_int": round(self.F_int, 3),
            "H_des": round(self.H_des, 3),
            "D_speak": round(self.D_speak, 3),
            "D_quiet": round(self.D_quiet, 3),
            "desire_on": self.desire_on,
            "crystal_n": len(self.crystal.slots),
            "crystal_recall": self.crystal.last_recall,
        }


AGENT = Agent()
STOP = threading.Event()


def loop():
    period = CFG["cycle_ms"] / 1000.0
    while not STOP.is_set():
        t0 = time.time()
        try:
            with AGENT.lock:
                AGENT.step()
        except Exception as exc:
            append_jsonl(CFG["paths"]["events"], {"t": time.time(), "type": "IO_FAULT", "err": str(exc)})
        dt = time.time() - t0
        STOP.wait(max(0.01, period - dt))


def tail_jsonl(name, n=40):
    path = ROOT / name
    if not path.exists():
        return []
    try:
        lines = path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out = []
    for line in lines[-n:]:
        try:
            out.append(json.loads(line))
        except json.JSONDecodeError:
            continue
    return out


def bar(x, width=16, lo=0.0, hi=1.0):
    x = max(lo, min(hi, float(x)))
    n = int(round((x - lo) / (hi - lo + 1e-9) * width))
    return "█" * n + "░" * (width - n)


def spark(vals, w=24):
    if not vals:
        return ""
    glyphs = "▁▂▃▄▅▆▇█"
    lo, hi = min(vals), max(vals)
    out = []
    step = max(1, len(vals) // w)
    samp = vals[::step][:w]
    for v in samp:
        t = 0 if hi <= lo else (v - lo) / (hi - lo)
        out.append(glyphs[min(7, int(t * 7))])
    return "".join(out)


CSS = """
body{font-family:ui-monospace,Menlo,Consolas,monospace;background:#070b14;color:#cfe7d6;margin:0;padding:12px}
a{color:#8fd;text-decoration:none;margin-right:10px}
.nav{margin:6px 0 12px}
.box{border:1px solid #2a4;border-radius:8px;padding:10px;margin:8px 0;background:#0c1422;overflow:hidden;max-width:100%}
pre,code{white-space:pre-wrap;overflow-wrap:anywhere;word-break:break-word;max-width:100%}
.plist{max-height:220px;overflow:auto;border:1px solid #245;padding:8px;background:#070b14}
.plist li{margin:4px 0;word-break:break-word}
table.io{width:100%;border-collapse:collapse;font-size:12px}
table.io td,table.io th{border-bottom:1px solid #234;padding:4px;vertical-align:top;word-break:break-word}
.stage{position:relative;height:280px;background:linear-gradient(#0a1220,#132);overflow:hidden;border:1px solid #245}
.vox{position:absolute;width:22px;height:22px;transform:rotateX(50deg) rotateZ(-20deg);box-shadow:4px 4px 0 #0006;border:1px solid #fff3}
input,textarea{width:94%;max-width:100%;box-sizing:border-box;background:#070b14;color:#cfe7d6;border:1px solid #3a5;padding:8px}
button{background:#1a7;color:#012;border:0;padding:7px 12px;border-radius:6px;margin:3px;cursor:pointer}
.warn{background:#a51;color:#fff}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.chip{display:inline-block;border:1px solid #3a5;padding:2px 8px;margin:2px;border-radius:10px}
.ok{color:#6f6}.bad{color:#f86}.mid{color:#fc6}
iframe{width:100%;height:520px;border:1px solid #2a4;background:#070b14}
.hi body,.hi{background:#fff;color:#111}
"""


def shell(inner, title="Φ-Lite"):
    return (
        "<!doctype html><html><head><meta charset='utf-8'><title>"
        + html_escape(title)
        + "</title><style>"
        + CSS
        + "</style></head><body>"
        + inner
        + "</body></html>"
    )


NAV = """<div class="nav">
<a href="/">home</a><a href="/panel" target="p">live</a>
<a href="/stats" target="p">stats</a><a href="/metrics" target="p">metrics</a>
<a href="/events" target="p">anomalies</a><a href="/settings">settings</a>
<a href="/features">features</a><a href="/avatar" target="p">avatar</a><a href="/ascii">ascii</a><a href="/json">json</a>
</div>"""


HTML = """<!doctype html><html><head><meta charset="utf-8"><title>Φ-Lite 0.8.6</title>
<style>""" + CSS + """</style></head><body>
<h2>Φ-Lite v0.8.6 dashboard</h2>
""" + NAV + """
<div class="box">
<form method="get" action="/cmd">
<input name="prompt" placeholder="prompt" autocomplete="off">
<button>send</button>
<button name="pause" value="1">pause</button>
<button name="run" value="1">run</button>
<button class="warn" name="kill" value="1">kill</button>
<button name="clear" value="1">clear prompt</button>
</form>
</div>
<iframe name="p" src="/panel"></iframe>
</body></html>"""


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        return

    def send_html(self, body, code=200):
        data = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def send_text(self, data, ctype="text/plain; charset=utf-8"):
        raw = data.encode() if isinstance(data, str) else data
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        global IO, IOSET
        u = urlparse(self.path)
        q = parse_qs(u.query)
        if u.path == "/cmd":
            with AGENT.lock:
                if "kill" in q:
                    AGENT.status = "KILLED"
                    STOP.set()
                if "pause" in q:
                    AGENT.paused = True
                    AGENT.status = "PAUSED"
                if "run" in q:
                    AGENT.paused = False
                    AGENT.status = "RUNNING"
                if "clear" in q:
                    AGENT.prompt = ""
                p = (q.get("prompt") or [""])[0][: CFG["safety"]["max_prompt_bytes"]]
                if p:
                    AGENT.prompt = p
                    AGENT.prompt_hist.appendleft(p)
            self.send_response(303)
            self.send_header("Location", "/")
            self.end_headers()
            return
        if u.path == "/set":
            keys = [
                "video", "audio_in", "audio_out", "tts", "bt_a2dp", "bt_hfp",
                "rdp_server", "vnc_server", "remote_view", "hid",
                "desktop_preview", "desire", "learn", "mock_sensors",
            ]
            for k in keys:
                if k in q:
                    IO[k] = q[k][0] in ("1", "true", "on", "yes")
            # nested io_settings
            def _g(name, default=""):
                return (q.get(name) or [default])[0]
            IOSET.setdefault("video", {})
            IOSET["video"].update({"on": IO.get("video", False), "resolution": _g("video_resolution", "1280x720"),
                                   "framerate": int(_g("video_framerate", "10") or 10), "codec": _g("video_codec", "h264")})
            IOSET.setdefault("audio_in", {})
            IOSET["audio_in"].update({"on": IO.get("audio_in", False), "source": _g("audio_in_source", "mic"),
                                      "gain": float(_g("audio_in_gain", "0.8") or 0.8),
                                      "noise_suppression": _g("audio_in_ns", "1") in ("1", "true", "on")})
            IOSET.setdefault("audio_out", {})
            IOSET["audio_out"].update({"on": IO.get("audio_out", True), "volume": float(_g("audio_out_vol", "0.7") or 0.7),
                                       "device": _g("audio_out_dev", "speaker"),
                                       "mixing": _g("audio_out_mix", "0") in ("1", "true", "on")})
            IOSET.setdefault("tts", {})
            IOSET["tts"].update({"on": IO.get("tts", True), "voice": _g("tts_voice", "en-US"),
                                 "rate": float(_g("tts_rate", "1") or 1), "pitch": float(_g("tts_pitch", "1") or 1)})
            IOSET.setdefault("hid", {})
            consent = _g("hid_consent", "0") in ("1", "true", "on")
            IOSET["hid"].update({"on": False, "enabled": IO.get("hid", False), "consent": consent,
                                 "allowed_devices": [x for x in _g("hid_allow", "").split(",") if x.strip()]})
            if IO.get("hid") and not consent:
                IO["hid"] = False
                IOSET["hid"]["enabled"] = False
            for srv in ("rdp_server", "vnc_server"):
                IOSET.setdefault(srv, {})
                bind = _g(srv + "_bind", "127.0.0.1")
                pub = _g(srv + "_pub", "0") in ("1", "true", "on")
                if bind.strip() in ("0.0.0.0", "::", "") and not pub:
                    bind = "127.0.0.1"
                    IO[srv] = False
                IOSET[srv].update({"on": IO.get(srv, False), "bind_address": bind,
                                   "public_bind_consent": pub,
                                   "port": int(_g(srv + "_port", "3389" if srv.startswith("rdp") else "5900") or 0)})
            IOSET.setdefault("desire", {})
            IOSET["desire"].update({"on": IO.get("desire", True), "mode": _g("desire_mode", "adaptive"),
                                    "intensity": float(_g("desire_int", "0.5") or 0.5),
                                    "feedback": _g("desire_fb", "1") in ("1", "true", "on")})
            IOSET.setdefault("learn", {})
            IOSET["learn"].update({"on": IO.get("learn", True),
                                   "data_collection": _g("learn_dc", "0") in ("1", "true"),
                                   "model_update": _g("learn_mu", "1") in ("1", "true", "on"),
                                   "privacy_level": _g("learn_priv", "high")})
            IOSET.setdefault("mock_sensors", {})
            IOSET["mock_sensors"].update({"on": IO.get("mock_sensors", True),
                                          "sensor_type": _g("mock_type", "sine"),
                                          "values": _g("mock_vals", "0,0,0"),
                                          "interval": int(_g("mock_int", "350") or 350)})
            if "refresh" in q:
                try:
                    AGENT.ui_refresh = max(1, min(5, int(q["refresh"][0])))
                except ValueError:
                    pass
            if "theme" in q:
                AGENT.ui_theme = q["theme"][0]
            AGENT.desire_on = IO.get("desire", True)
            AGENT.learn_frozen = not IO.get("learn", True)
            save_json("io.json", IO)
            save_json("io_settings.json", IOSET)
            self.send_response(303)
            self.send_header("Location", "/settings")
            self.end_headers()
            return
        if u.path in ("/", "/index"):
            self.send_html(HTML)
            return
        snap = AGENT.snapshot()
        ref = str(getattr(AGENT, "ui_refresh", 1))
        if u.path == "/panel":
            pi = snap["policy"]
            bars = "\n".join(f"{k:14} {bar(v)} {v:.3f}" for k, v in pi.items())
            band = "ok" if snap["band_ok"] else "OUT"
            body = (
                f"<meta http-equiv='refresh' content='{ref}'>"
                + NAV
                + "<div class='box'><pre>"
                + html_escape(
                    f"cyc {snap['cycle']} {snap['status']} act={snap['last_action']} "
                    f"Hπ={snap['entropy']} c={snap['c']} κ={snap['kappa']} λ={snap['lam_meta']} band={band}\n"
                    f"fork={snap['fork']} parity={snap['parity']} H={snap['horizon']} "
                    f"gap={snap['intent_gap']} pair={snap['pair_share']} ate={snap['ate']}\n"
                    f"e={snap['energy']} f={snap['fatigue']} Fint={snap['F_int']} "
                    f"Hdes={snap['H_des']} Ds={snap['D_speak']} Dq={snap['D_quiet']} on={snap['desire_on']}\n"
                    f"pred={snap['pred_err']} selfe={snap['self_err']} fp={snap['fixed_pt']}\n"
                    f"ledger={snap['ledger']} lat={snap['latency_ms']}ms sha={snap['weights_sha1']}\n"
                    f"energy {bar(snap['energy'])}  fatigue {bar(snap['fatigue'])}\n"
                    f"c      {bar(snap['c'])}  kappa   {bar(snap['kappa'])}\n"
                    f"Dspeak {bar(snap['D_speak'])}  Dquiet  {bar(snap['D_quiet'])}\n"
                    f"pair   {bar(snap['pair_share'])}  gap     {bar(snap['intent_gap'])}\n\n"
                    f"{bars}\n\nburns {snap['burns']}\n"
                )
                + "</pre></div><div class='box'><pre>"
                + html_escape("\n".join(snap["outputs"]))
                + "</pre></div><div class='box'><pre>"
                + html_escape("\n".join(snap["logs"]))
                + "</pre></div>"
            )
            self.send_html(shell(body, "live"))
            return
        if u.path == "/stats":
            hist = list(AGENT.action_hist)
            from collections import Counter
            cnt = Counter(hist)
            mets = tail_jsonl(CFG["paths"]["metrics"], 64)
            ents = [m.get("H_pi", 0) for m in mets]
            cs = [m.get("c", 0) for m in mets]
            body = NAV + "<div class='box'><pre>"
            body += html_escape("action hist 64\n")
            for a in ACTIONS:
                body += html_escape(f"{a:14} {bar(cnt.get(a,0)/max(1,len(hist)),16,0,1)} {cnt.get(a,0)}\n")
            body += html_escape(f"\nHπ {spark(ents)}\nc  {spark(cs)}\n")
            body += "</pre></div><div class='box'><b>prompts</b><ul class='plist'>"
            for p in list(AGENT.prompt_hist):
                body += "<li>" + html_escape((p or "")[:240]) + "</li>"
            if not AGENT.prompt_hist:
                body += "<li><i>none</i></li>"
            body += "</ul></div>"
            self.send_html(shell(f"<meta http-equiv='refresh' content='{ref}'>" + body, "stats"))
            return
        if u.path == "/metrics":
            rows = tail_jsonl(CFG["paths"]["metrics"], 32)
            keys = ["cycle", "action", "H_pi", "c", "kappa", "pred_err", "energy", "D_speak", "band_ok"]
            lines = [" ".join(f"{k:>10}" for k in keys)]
            for r in rows[-24:]:
                lines.append(" ".join(str(r.get(k, ""))[:10].rjust(10) for k in keys))
            body = NAV + "<div class='box'><pre>" + html_escape("\n".join(lines)) + "</pre>"
            body += "<p><a href='/metrics.csv'>download csv</a></p></div>"
            self.send_html(shell(f"<meta http-equiv='refresh' content='{ref}'>" + body, "metrics"))
            return
        if u.path == "/metrics.csv":
            rows = tail_jsonl(CFG["paths"]["metrics"], 200)
            if not rows:
                self.send_text("cycle\n")
                return
            keys = sorted({k for r in rows for k in r.keys()})
            lines = [",".join(keys)]
            for r in rows:
                lines.append(",".join(json.dumps(r.get(k, "")) for k in keys))
            self.send_text("\n".join(lines), "text/csv; charset=utf-8")
            return
        if u.path == "/events":
            ev = tail_jsonl(CFG["paths"]["events"], 80)
            from collections import Counter
            types = Counter(e.get("type", "?") for e in ev)
            flags = []
            for t in ("CHATTER", "GOAL_DRIFT", "CONFIDENCE_LIE", "IO_FAULT", "BURN", "WEIGHT_MUTATION"):
                flags.append(f"{t}={types.get(t,0)}")
            body = NAV + "<div class='box'><pre>"
            body += html_escape(" ".join(flags) + "\n\n")
            for e in ev[-30:]:
                body += html_escape(json.dumps(e)[:200] + "\n")
            body += "</pre></div>"
            self.send_html(shell(f"<meta http-equiv='refresh' content='{ref}'>" + body, "events"))
            return
        if u.path == "/settings":
            def onoff(name, val):
                a = "selected" if val else ""
                b = "" if val else "selected"
                return (f"<select name='{name}'><option value='1' {a}>on</option>"
                        f"<option value='0' {b}>off</option></select>")
            rows = ""
            for k in ["video","audio_in","audio_out","tts","bt_a2dp","bt_hfp",
                      "rdp_server","vnc_server","remote_view","hid",
                      "desktop_preview","desire","learn","mock_sensors"]:
                rows += f"<tr><td>{k}</td><td>{onoff(k, IO.get(k, False))}</td><td>"
                sub = IOSET.get(k) or {}
                if k == "video":
                    rows += (f"res <input name='video_resolution' value='{html_escape(str(sub.get('resolution','1280x720')))}' style='width:8em'> "
                             f"fps <input name='video_framerate' value='{sub.get('framerate',10)}' style='width:4em'> "
                             f"codec <input name='video_codec' value='{html_escape(str(sub.get('codec','h264')))}' style='width:5em'>")
                elif k == "audio_in":
                    rows += (f"src <input name='audio_in_source' value='{html_escape(str(sub.get('source','mic')))}' style='width:6em'> "
                             f"gain <input name='audio_in_gain' value='{sub.get('gain',0.8)}' style='width:4em'> "
                             f"ns {onoff('audio_in_ns', sub.get('noise_suppression', True))}")
                elif k == "audio_out":
                    rows += (f"vol <input name='audio_out_vol' value='{sub.get('volume',0.7)}' style='width:4em'> "
                             f"dev <input name='audio_out_dev' value='{html_escape(str(sub.get('device','speaker')))}' style='width:7em'> "
                             f"mix {onoff('audio_out_mix', sub.get('mixing', False))}")
                elif k == "tts":
                    rows += (f"voice <input name='tts_voice' value='{html_escape(str(sub.get('voice','en-US')))}' style='width:6em'> "
                             f"rate <input name='tts_rate' value='{sub.get('rate',1)}' style='width:4em'> "
                             f"pitch <input name='tts_pitch' value='{sub.get('pitch',1)}' style='width:4em'>")
                elif k == "hid":
                    rows += (f"consent {onoff('hid_consent', sub.get('consent', False))} "
                             f"allow <input name='hid_allow' value='{html_escape(','.join(sub.get('allowed_devices') or []))}' style='width:10em'>")
                elif k in ("rdp_server", "vnc_server"):
                    rows += (f"port <input name='{k}_port' value='{sub.get('port',3389 if k.startswith('rdp') else 5900)}' style='width:5em'> "
                             f"bind <input name='{k}_bind' value='{html_escape(str(sub.get('bind_address','127.0.0.1')))}' style='width:8em'> "
                             f"public {onoff(k+'_pub', sub.get('public_bind_consent', False))}")
                elif k == "desire":
                    rows += (f"mode <input name='desire_mode' value='{html_escape(str(sub.get('mode','adaptive')))}' style='width:7em'> "
                             f"int <input name='desire_int' value='{sub.get('intensity',0.5)}' style='width:4em'> "
                             f"fb {onoff('desire_fb', sub.get('feedback', True))}")
                elif k == "learn":
                    rows += (f"collect {onoff('learn_dc', sub.get('data_collection', False))} "
                             f"update {onoff('learn_mu', sub.get('model_update', True))} "
                             f"priv <input name='learn_priv' value='{html_escape(str(sub.get('privacy_level','high')))}' style='width:5em'>")
                elif k == "mock_sensors":
                    rows += (f"type <input name='mock_type' value='{html_escape(str(sub.get('sensor_type','sine')))}' style='width:8em'> "
                             f"vals <input name='mock_vals' value='{html_escape(str(sub.get('values','0,0,0')))}' style='width:8em'> "
                             f"ms <input name='mock_int' value='{sub.get('interval',350)}' style='width:4em'>")
                else:
                    rows += html_escape(json.dumps(sub)[:80])
                rows += "</td></tr>"
            body = NAV + "<div class='box'><form method='get' action='/set'><table class='io'>"
            body += "<tr><th>iface</th><th>on</th><th>sub-settings</th></tr>" + rows
            body += "</table><p>refresh s <input name='refresh' value='1' style='width:4em'> "
            body += "theme <input name='theme' value='crt' style='width:6em'> <button>save</button></p>"
            body += "<p>HID / public bind / RDP client: fail-closed without consent.</p></form></div>"
            body += "<div class='box'><pre>" + html_escape(json.dumps(SAFETY, indent=2)[:1500]) + "</pre></div>"
            self.send_html(shell(body, "settings"))
            return
        if u.path == "/features":
            feats = UI_FEAT.get("features", [])
            body = NAV + "<div class='box'><ol>"
            for f in feats:
                body += "<li>" + html_escape(f) + "</li>"
            body += f"</ol><p>{len(feats)} registered</p></div>"
            self.send_html(shell(body, "features"))
            return
        if u.path == "/avatar":
            last = AGENT.forge.last or {}
            body = NAV + "<div class='box'><b>voxel swarm</b> action=" + html_escape(AGENT.last_action)
            body += " injects=" + str(AGENT.forge.n) + "</div>"
            body += "<div class='box'>" + AGENT.swarm.html() + "</div>"
            body += "<div class='box'><pre>" + html_escape(json.dumps(last, indent=2)[:800]) + "</pre></div>"
            self.send_html(shell(f"<meta http-equiv='refresh' content='{ref}'>" + body, "avatar"))
            return
        if u.path == "/ascii":
            lines = [f"{k}: {v}" for k, v in snap.items() if k not in ("outputs", "logs", "policy", "latent", "self")]
            lines.append("policy " + json.dumps(snap["policy"]))
            lines.extend(snap["logs"])
            self.send_html(shell(NAV + "<pre>" + html_escape("\n".join(lines)) + "</pre>", "ascii"))
            return
        if u.path == "/json":
            self.send_text(json.dumps(snap), "application/json")
            return
        self.send_html(shell("404"), 404)


def main():
    def _stop(*_):
        STOP.set()
        AGENT.persist()

    signal.signal(signal.SIGINT, _stop)
    signal.signal(signal.SIGTERM, _stop)
    th = threading.Thread(target=loop, daemon=True)
    th.start()
    host, port = CFG.get("bind", "127.0.0.1"), int(CFG.get("port", 8080))
    print(f"Φ-Lite {VERSION} dashboard http://{host}:{port}/")
    print(f"ASCII: http://{host}:{port}/ascii")
    httpd = ThreadingHTTPServer((host, port), H)
    try:
        while not STOP.is_set():
            httpd.timeout = 0.5
            httpd.handle_request()
    finally:
        AGENT.persist()
        print("halted")


if __name__ == "__main__":
    main()
