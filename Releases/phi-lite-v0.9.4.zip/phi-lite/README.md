# Φ-Lite 0.8.5
Stats prompts wrap in .plist. Settings: 14 ifaces x sub-keys, HID/public bind fail-closed.
python3 phi_lite.py

