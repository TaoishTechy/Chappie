# Φ-Lite v0.6.0

Slim closed-loop agent. Stage target 3.2-3.6 if gates pass. Not Stage 5.

python3 phi_lite.py
http://127.0.0.1:8080/

