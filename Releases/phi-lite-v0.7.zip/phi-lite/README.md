# Φ-Lite v0.7.0

Homeostasis + 8-drive desire on top of v0.6 band/kappa/burns.
python3 phi_lite.py
http://127.0.0.1:8080/
Not Stage 5. Desire nulls itself on CHATTER.

