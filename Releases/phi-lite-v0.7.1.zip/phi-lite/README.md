# Φ-Lite v0.7.1

Dashboard: home / live / stats / metrics / anomalies / settings / features
I/O toggles in /settings (select on/off). Prompt form does not steal focus.
python3 phi_lite.py

